# Build & Run Claims Frontend Container

## Prerequisites
- Docker installed
- Optum NPM Token (from Artifactory)

---

## Build the Docker Image

```bash
# Set your Optum NPM token
export NPM_TOKEN="your-optum-artifactory-token"

# Build the image
docker build \
  --build-arg NPM_TOKEN="${NPM_TOKEN}" \
  -t claims-frontend:latest .
```

**What happens:**
1. Installs dependencies from Optum Artifactory
2. Compiles TypeScript
3. Builds React app with Vite
4. Copies server runtime files to dist/

---

## Run the Container Locally

### ❌ WILL FAIL (Missing Required Environment Variables)
```bash
docker run -p 3000:3000 claims-frontend:latest
# Error: Missing required environment variables: AUTH_API_BASE_URL, AGENTIC_API_BASE_URL
```

### ✅ REQUIRED: With Mandatory Environment Variables
```bash
docker run \
  -p 3000:3000 \
  -e AUTH_API_BASE_URL="https://claims-api-uat.optum.com" \
  -e AGENTIC_API_BASE_URL="https://agentic-uat.optum.com" \
  claims-frontend:latest
```

### ✅ OPTIONAL: With Additional Configuration
```bash
docker run \
  -p 3000:3000 \
  -e AUTH_API_BASE_URL="https://claims-api-uat.optum.com" \
  -e AGENTIC_API_BASE_URL="https://agentic-uat.optum.com" \
  -e CLIENT_NAME="Claims Dashboard" \
  -e CLIENT_LOGO="https://your-logo-url/logo.png" \
  claims-frontend:latest
```

### ✅ Run in Background
```bash
docker run -d \
  -p 3000:3000 \
  --name claims-app \
  -e AUTH_API_BASE_URL="https://claims-api-uat.optum.com" \
  -e AGENTIC_API_BASE_URL="https://agentic-uat.optum.com" \
  claims-frontend:latest

# View logs
docker logs -f claims-app

# Stop
docker stop claims-app
```

---

## Test the Application

```bash
# Check if app is running
curl http://localhost:3000

# Check config endpoint
curl http://localhost:3000/config.js

# Expected output:
# window.__RUNTIME_CONFIG__={"VITE_AUTH_API_BASE_URL":"http://localhost:8080",...}
```

---

## Environment Variables (Runtime)

These must be set when starting the container:

### 🔴 REQUIRED Variables

| Variable | Example | Purpose |
|----------|---------|---------|
| `AUTH_API_BASE_URL` or `VITE_AUTH_API_BASE_URL` | `https://claims-api-uat.optum.com` | Backend authentication service (REQUIRED) |
| `AGENTIC_API_BASE_URL` or `VITE_AGENTIC_API_BASE_URL` | `https://agentic-uat.optum.com` | Agentic service endpoint (REQUIRED) |

### 🟢 OPTIONAL Variables

| Variable | Example | Purpose |
|----------|---------|---------|
| `PORT` | `3000` | Server port (default: 3000) |
| `HOST` | `0.0.0.0` | Listen address (default: 0.0.0.0) |
| `NODE_ENV` | `production` | Environment mode (default: production) |
| `CLIENT_NAME` | `Optum Claims Dashboard` | App display name (optional) |
| `CLIENT_LOGO` | `https://...` | Logo URL for branding (optional) |

**Note**: If you don't provide the required variables, the app will fail to start with a clear error message.

---

## Docker Compose (Required Environment Variables)

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  frontend:
    build:
      context: .
      args:
        NPM_TOKEN: ${NPM_TOKEN}
    ports:
      - "3000:3000"
    environment:
      # REQUIRED - must be provided
      AUTH_API_BASE_URL: ${AUTH_API_BASE_URL:-https://claims-api-uat.optum.com}
      AGENTIC_API_BASE_URL: ${AGENTIC_API_BASE_URL:-https://agentic-uat.optum.com}
      # OPTIONAL
      CLIENT_NAME: "Claims Dashboard"
      CLIENT_LOGO: "https://your-logo-url/logo.png"
    restart: unless-stopped
```

Run with required variables:
```bash
export NPM_TOKEN="your-token"
export AUTH_API_BASE_URL="https://claims-api-uat.optum.com"
export AGENTIC_API_BASE_URL="https://agentic-uat.optum.com"
docker-compose up
```

Or pass them directly:
```bash
AUTH_API_BASE_URL=https://api.optum.com \
AGENTIC_API_BASE_URL=https://agentic.optum.com \
NPM_TOKEN=your-token \
docker-compose up
```

---

## Troubleshooting

### Build fails: "npm ERR! auth"
**Solution**: Check NPM_TOKEN is valid and not expired

### Container starts but won't respond
```bash
docker logs <container-id>
```
Check for error messages

### Port 3000 already in use
```bash
# Use different port
docker run -p 8000:3000 claims-frontend:latest
# App runs on 3000 inside container, accessible at localhost:8000
```

### Config.js returns empty values
**Solution**: Set environment variables when running container:
```bash
docker run -e AUTH_API_BASE_URL="https://..." claims-frontend:latest
```

---

## Production Deployment

### Azure App Services
See [AZURE_DEPLOYMENT_GUIDE.md](./AZURE_DEPLOYMENT_GUIDE.md)

### Kubernetes
```bash
docker tag claims-frontend:latest myregistry.azurecr.io/claims-frontend:v1.0
docker push myregistry.azurecr.io/claims-frontend:v1.0
```

### Docker Registry
```bash
docker tag claims-frontend:latest myregistry/claims-frontend:latest
docker push myregistry/claims-frontend:latest
```

---

## Next Steps

1. ✅ Build: `docker build --build-arg NPM_TOKEN="..." -t claims-frontend:latest .`
2. ✅ Run: `docker run -p 3000:3000 claims-frontend:latest`
3. ✅ Test: `curl http://localhost:3000`
4. ✅ Deploy: Push to your container registry and deploy

