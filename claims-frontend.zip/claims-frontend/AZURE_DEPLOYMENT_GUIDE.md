# Azure App Services Deployment Guide - Claims Frontend

## Quick Start

This guide assumes you're deploying the claims-frontend Docker image to Azure App Services.

---

## Prerequisites

- Azure subscription with App Service available
- Azure Container Registry (ACR) or Docker Hub account
- Docker installed locally (or use Azure DevOps/GitHub Actions)
- `az` CLI installed (optional, for command-line deployment)

---

## Step 1: Build the Docker Image

### Build locally for testing:
```bash
# Set your npm token (from Optum Artifactory)
NPM_TOKEN="your-optum-npm-token-here"

docker build \
  --build-arg NPM_TOKEN="${NPM_TOKEN}" \
  -t claims-frontend:latest .
```

### Test locally:
```bash
docker run \
  -p 3000:3000 \
  -e AUTH_API_BASE_URL="http://localhost:8080" \
  -e AGENTIC_API_BASE_URL="http://localhost:8081" \
  claims-frontend:latest

# Verify:
# curl http://localhost:3000        # App loads
# curl http://localhost:3000/config.js  # Config endpoint
```

---

## Step 2: Push to Azure Container Registry

### Login to ACR:
```bash
az acr login --name <your-acr-name>
```

### Build and push in one command:
```bash
az acr build \
  --registry <your-acr-name> \
  --build-arg NPM_TOKEN="${NPM_TOKEN}" \
  --image claims-frontend:uat \
  .
```

Or **build locally and push**:
```bash
docker tag claims-frontend:latest <your-acr-name>.azurecr.io/claims-frontend:uat
docker push <your-acr-name>.azurecr.io/claims-frontend:uat
```

---

## Step 3: Create/Update Azure App Service

### Option A: Using Azure Portal

1. **Create App Service** (if new):
   - Resource Group: Select or create
   - Name: `claims-frontend-uat` (example)
   - Publish: Docker Container
   - OS: Linux
   - Region: Select your Optum region

2. **Configure Docker Image**:
   - Image Source: Azure Container Registry (ACR)
   - Registry: Select your ACR
   - Image: `claims-frontend`
   - Tag: `uat` (or your version)
   - Startup Command: Leave blank (uses Dockerfile CMD)

3. **Configure Application Settings**:
   - Go to **Settings → Configuration → Application Settings**
   - Add these variables:

   ```
   PORT=3000
   HOST=0.0.0.0
   NODE_ENV=production
   AUTH_API_BASE_URL=https://claims-api-uat.optum.com
   AGENTIC_API_BASE_URL=https://agentic-uat.optum.com
   CLIENT_NAME=Optum Claims Dashboard
   CLIENT_LOGO=https://your-logo-url/logo.png
   ```

4. **Save and Restart App Service**

### Option B: Using Azure CLI

```bash
# Create resource group (if needed)
az group create \
  --name rg-claims-frontend \
  --location eastus

# Create App Service Plan
az appservice plan create \
  --name asp-claims-frontend \
  --resource-group rg-claims-frontend \
  --sku B2 \
  --is-linux

# Create App Service
az webapp create \
  --resource-group rg-claims-frontend \
  --plan asp-claims-frontend \
  --name claims-frontend-uat \
  --deployment-container-image-name <your-acr-name>.azurecr.io/claims-frontend:uat

# Configure ACR authentication
az webapp config container set \
  --resource-group rg-claims-frontend \
  --name claims-frontend-uat \
  --docker-custom-image-name <your-acr-name>.azurecr.io/claims-frontend:uat \
  --docker-registry-server-url https://<your-acr-name>.azurecr.io \
  --docker-registry-server-user <acr-username> \
  --docker-registry-server-password <acr-password>

# Add application settings
az webapp config appsettings set \
  --resource-group rg-claims-frontend \
  --name claims-frontend-uat \
  --settings \
    PORT=3000 \
    HOST=0.0.0.0 \
    NODE_ENV=production \
    AUTH_API_BASE_URL=https://claims-api-uat.optum.com \
    AGENTIC_API_BASE_URL=https://agentic-uat.optum.com
```

---

## Step 4: Configure Networking

### Inbound Rules
- Allow traffic on port 3000 from your VPN/corporate network
- Azure App Services handle HTTPS termination

### Environment Variables Summary

| Variable | Example Value | Purpose |
|----------|---------------|---------|
| `PORT` | `3000` | Application port (required) |
| `HOST` | `0.0.0.0` | Listen on all interfaces (required) |
| `NODE_ENV` | `production` | Production mode |
| `AUTH_API_BASE_URL` | `https://claims-api-uat.optum.com` | Backend authentication service |
| `AGENTIC_API_BASE_URL` | `https://agentic-uat.optum.com` | Agentic service endpoint |
| `CLIENT_NAME` | `Optum Claims Dashboard` | App display name |
| `CLIENT_LOGO` | `https://...` | Logo URL for branding |
| `VITE_DEFAULT_WORKFLOW_ID` | `claims-workflow-v1` | Default workflow (optional) |

---

## Step 5: Verify Deployment

### Health Checks
```bash
# Replace with your App Service URL
APP_URL="https://claims-frontend-uat.azurewebsites.net"

# Check app is running
curl -I "$APP_URL"

# Check config endpoint
curl "$APP_URL/config.js"
# Should return: window.__RUNTIME_CONFIG__={...}

# Check specific asset
curl -I "$APP_URL/index.html"
```

### Expected Responses

✅ **200 OK** - HTML page loads  
✅ **200 OK** - /config.js returns config payload  
✅ **200 OK** - Static assets (JS, CSS) available  
✅ **200 OK** - Deep routes return index.html (SPA fallback)

### Azure Portal Checks
1. Go to **App Service → Overview**
   - Status should be "Running"
   - Instance state should be "Ready"

2. Go to **App Service → Monitoring → Application Insights** (if enabled)
   - Check for errors
   - Monitor response times

3. Go to **App Service → Log Stream**
   - Watch for startup logs
   - Should see: `npm run start` output
   - Should see: server listening on 3000

---

## Step 6: Post-Deployment Configuration

### SSL/TLS Certificate
- Azure App Services provide free SSL by default (`*.azurewebsites.net`)
- For custom domain:
  - Add domain to App Service
  - Create free certificate or import your own

### Auto-Scale (Optional)
For production:
1. Go to **App Service Plan → Scale out**
2. Enable auto-scale based on CPU/Memory
3. Set minimum 2 instances for HA

### Monitoring & Alerts
1. Go to **App Service → Alerts**
2. Create alert for:
   - HTTP 5xx errors
   - Long response times
   - High CPU/Memory

---

## Troubleshooting

### Container won't start
```bash
# Check logs
az webapp log tail --resource-group rg-claims-frontend --name claims-frontend-uat

# Should see:
# npm run start
# Serving /app/dist
# → http://localhost:3000
```

### Config.js returns empty or incorrect values
- **Cause**: Environment variables not set in App Settings
- **Fix**: Go to Configuration → Application Settings
- **Add**: AUTH_API_BASE_URL, AGENTIC_API_BASE_URL, etc.

### 404 on deep routes
- **Cause**: React Router deep links not working
- **Fix**: serve-dist.mjs has SPA fallback built-in, should work
- **Check**: Can you access /index.html? If yes, the server is working

### Slow first load
- **Cause**: App Service cold start or Node.js startup
- **Fix**: Use "Always On" setting for production
- **Location**: App Service → Configuration → General settings

### Backend API unreachable
- **Cause**: Firewall/network rules blocking API access
- **Fix**: Check Optum network connectivity
- **Verify**: Can App Service reach API from local machine?

---

## CI/CD Pipeline Example (GitHub Actions)

```yaml
name: Deploy to Azure App Service

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - name: Login to ACR
        run: |
          az login --service-principal \
            -u ${{ secrets.AZURE_CLIENT_ID }} \
            -p ${{ secrets.AZURE_CLIENT_SECRET }} \
            --tenant ${{ secrets.AZURE_TENANT_ID }}

      - name: Build and Push to ACR
        run: |
          az acr build \
            --registry ${{ secrets.ACR_NAME }} \
            --build-arg NPM_TOKEN=${{ secrets.NPM_TOKEN }} \
            --image claims-frontend:${{ github.sha }} \
            --image claims-frontend:latest \
            .

      - name: Deploy to App Service
        run: |
          az webapp config container set \
            --resource-group rg-claims-frontend \
            --name claims-frontend-uat \
            --docker-custom-image-name ${{ secrets.ACR_NAME }}.azurecr.io/claims-frontend:latest
```

---

## Rollback Procedure

If deployment fails or issues found:

```bash
# Revert to previous image
az webapp config container set \
  --resource-group rg-claims-frontend \
  --name claims-frontend-uat \
  --docker-custom-image-name <your-acr-name>.azurecr.io/claims-frontend:previous-tag
```

---

## Performance Tips

1. **Enable Application Insights** for monitoring
2. **Use "Always On"** for production to prevent cold starts
3. **Enable Managed Identity** instead of registry credentials
4. **Set up Log Analytics** for long-term monitoring
5. **Use Premium SKU** for better CPU/memory for production

---

## Related Documentation

- [Azure App Service Docker Documentation](https://docs.microsoft.com/en-us/azure/app-service/configure-custom-container)
- [Azure Container Registry](https://docs.microsoft.com/en-us/azure/container-registry/)
- [Optum Docker Registry](https://edgeinternal1uhg.optum.com/)

---

## Support

For issues:
1. Check logs: `az webapp log tail ...`
2. Review [DOCKERFILE_ANALYSIS.md](./DOCKERFILE_ANALYSIS.md)
3. Verify environment variables in App Settings
4. Test locally with Docker first: `docker run -e VAR=value ...`

