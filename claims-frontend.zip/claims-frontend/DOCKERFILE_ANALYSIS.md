# Dockerfile Analysis & Azure App Services Deployment Guide

## Executive Summary
✅ The updated Dockerfile is now **aligned with Optum best practices** and ready for Azure App Services deployment. Key improvements made:
1. Added VITE build args for flexibility
2. Added `always-auth=false` to npm config
3. Enhanced documentation for cloud deployment
4. Maintained security best practices (non-root user, npm ci)

---

## Comparison: Current vs. Reference Dockerfile

| Aspect | Current (Original) | Reference | Updated | Notes |
|--------|-------------------|-----------|---------|-------|
| **Base Image** | ✅ Optum Golden Image | ✅ Same | ✅ Same | Correct for Optum environment |
| **NPM Registry** | ✅ Artifactory | ✅ Same | ✅ Same | Optum standard |
| **NPM Token Auth** | ✅ Configured | ✅ Same | ✅ Same | Secure credential passing |
| **.npmrc Config** | ⚠️ Missing `always-auth=false` | ✅ Has it | ✅ Added | Improves npm reliability |
| **Non-root User** | ✅ Yes (node:node) | ✅ Same | ✅ Same | Security best practice |
| **Install Method** | ✅ `npm ci` (better) | ❌ `npm install` | ✅ `npm ci` | Production best practice |
| **VITE Build Args** | ❌ Missing | ✅ Has 3 args | ✅ Added 5 args | Build-time config flexibility |
| **Port Exposure** | ✅ 3000 | ✅ Same | ✅ Same | Azure App Services compatible |
| **Server** | ✅ serve-dist.mjs | ✅ Same | ✅ Same | Zero-dependency SPA server |
| **Documentation** | ⚠️ Minimal | ⚠️ Basic | ✅ Enhanced | For Azure App Services clarity |

---

## Key Architecture Details

### Runtime Configuration (Azure-Friendly Design)
The application uses a **runtime config endpoint** (`/config.js`) rather than baking all config into the build:

```javascript
// Generated at runtime by serve-dist.mjs → runtime-config.mjs
window.__RUNTIME_CONFIG__ = {
  VITE_AUTH_API_BASE_URL: "...",
  VITE_AGENTIC_API_BASE_URL: "...",
  VITE_CLIENT_NAME: "...",
  VITE_CLIENT_LOGO: "..."
}
```

**Advantages for Azure App Services:**
- ✅ Configuration can be changed without rebuilding the Docker image
- ✅ Supports multiple environment promotion (Dev → UAT → Prod)
- ✅ Environment variables can be injected at container startup
- ✅ Flexible credential injection via Azure App Services settings

### Dual Config Support
The runtime config accepts **both** VITE-prefixed and unprefixed variable names:

```bash
# These work interchangeably:
VITE_AUTH_API_BASE_URL=https://...  # VITE standard
AUTH_API_BASE_URL=https://...       # Docker-friendly alias

# Priority: VITE_* → unprefixed alias → default
```

---

## Updated Dockerfile Features

### 1. **Optum Artifactory Configuration**
```dockerfile
ENV NPM_CONFIG_REGISTRY=https://edgeinternal1uhg.optum.com/artifactory/api/npm/a11ydashboard-npm-vir/
```
- Pulls packages from Optum's private npm registry
- Requires `NPM_TOKEN` build argument

### 2. **Improved .npmrc Setup**
```dockerfile
RUN printf '%s\n' \
    'registry=...' \
    '_authToken=...' \
    'always-auth=false'    # ← NEW: More robust npm behavior
```
- `always-auth=false` allows npm to fall back gracefully if auth fails on public packages

### 3. **Non-Root Security**
```dockerfile
USER root
RUN mkdir -p /app && chown -R node:node /app
USER node
WORKDIR /app
```
- Container runs as `node:node` (non-root user)
- Prevents privilege escalation attacks
- Files are writable by node user during build

### 4. **Production-Grade Dependency Installation**
```dockerfile
RUN npm ci --include=dev
```
- `npm ci` (Clean Install) instead of `npm install`
- Respects `package-lock.json` for reproducible builds
- Better for production Docker images

### 5. **Flexible Build-Time Configuration**
```dockerfile
ARG VITE_AUTH_API_BASE_URL
ARG VITE_AGENTIC_API_BASE_URL
ARG VITE_DEFAULT_WORKFLOW_ID
ARG VITE_CLIENT_NAME
ARG VITE_CLIENT_LOGO

ENV VITE_AUTH_API_BASE_URL=${VITE_AUTH_API_BASE_URL}
# ... etc
```
- Optional build arguments for build-time config baking
- Falls back to runtime config if not provided
- Best of both worlds: flexibility + performance

### 6. **Azure App Services Ready**
```dockerfile
EXPOSE 3000
# Accessible from Azure App Services port binding
# Environment variables injected at runtime
# Health checks can hit /config.js or static assets
```

---

## Building for Azure App Services

### Option A: Build Locally with Config Baking (Fast Runtime)
```bash
docker build \
  --build-arg NPM_TOKEN="<your-token>" \
  --build-arg VITE_AUTH_API_BASE_URL="https://claims-api-uat.optum.com" \
  --build-arg VITE_AGENTIC_API_BASE_URL="https://agentic-uat.optum.com" \
  --build-arg VITE_DEFAULT_WORKFLOW_ID="claims-workflow-v1" \
  -t claims-frontend:uat .
```

### Option B: Build Without Args, Use Runtime Config (Most Flexible)
```bash
docker build \
  --build-arg NPM_TOKEN="<your-token>" \
  -t claims-frontend:uat .

# Then run with environment variables:
docker run \
  -e AUTH_API_BASE_URL="https://claims-api-uat.optum.com" \
  -e AGENTIC_API_BASE_URL="https://agentic-uat.optum.com" \
  -p 3000:3000 \
  claims-frontend:uat
```

### Azure App Services Deployment (Recommended)
1. **Build image without VITE args** (keep image generic)
2. **Push to Azure Container Registry (ACR)**
3. **Deploy to App Service → App Settings** add environment variables:
   - `PORT` = `3000`
   - `HOST` = `0.0.0.0`
   - `AUTH_API_BASE_URL` = `https://claims-api-uat.optum.com`
   - `AGENTIC_API_BASE_URL` = `https://agentic-uat.optum.com`
   - etc.

---

## Runtime Server Details

### serve-dist.mjs (Zero-Dependency Server)
- **Port**: 3000 (configurable via `PORT` env var)
- **Host**: 0.0.0.0 (listens on all interfaces)
- **Features**:
  - SPA fallback: unknown routes → `index.html` (React Router friendly)
  - Static file serving with correct MIME types
  - Cache-Control headers
  - No external dependencies (lightweight)

### Health Check Endpoint
For Azure App Services, you can use:
```bash
curl http://localhost:3000/index.html  # App loads
curl http://localhost:3000/config.js   # Runtime config available
```

---

## Build Script Analysis

```json
{
  "build": "tsc -b && vite build && node scripts/copy-server-dist.mjs",
  "start": "node dist/server-dist.mjs"
}
```

1. **`tsc -b`** → TypeScript full build
2. **`vite build`** → React app compiled to `dist/`
3. **`node scripts/copy-server-dist.mjs`** → Copies server runtime files to `dist/server-dist.mjs`
4. **`npm start`** → Runs the server

---

## Differences from Reference Dockerfile

| Feature | Reference | Updated | Why |
|---------|-----------|---------|-----|
| Base Image | Same | Same | Optum standard |
| npm install vs npm ci | `npm install` | `npm ci` | Better for reproducibility |
| VITE Args Count | 3 (basic) | 5 (comprehensive) | Supports CLIENT_NAME/LOGO |
| .npmrc Config | Has always-auth | Added | Robustness |
| Comments | Basic | Extensive | Azure deployment clarity |
| Build Output Comments | Minimal | Detailed | Better for CI/CD pipelines |

---

## Security Checklist

✅ **Non-root user** (node:node)  
✅ **Artifact authentication** (NPM_TOKEN)  
✅ **No secrets in image** (passed as build args)  
✅ **Minimal dependencies** (zero-dep server)  
✅ **Health check ready** (static files + runtime config endpoint)  
✅ **HTTPS ready** (Azure App Services handles TLS)  

---

## Next Steps

1. **Build & Test Locally**
   ```bash
   docker build --build-arg NPM_TOKEN="..." -t claims-frontend:test .
   docker run -p 3000:3000 -e AUTH_API_BASE_URL="http://localhost:8080" claims-frontend:test
   ```

2. **Push to Azure Container Registry**
   ```bash
   az acr build --registry <acr-name> --image claims-frontend:uat .
   ```

3. **Deploy to App Service**
   - Use Azure Portal or Azure CLI
   - Configure App Settings with environment variables
   - Set PORT to 3000, HOST to 0.0.0.0

4. **Verify Deployment**
   ```bash
   curl https://<app-name>.azurewebsites.net/config.js
   curl https://<app-name>.azurewebsites.net/
   ```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `npm ci` fails with auth | Check `NPM_TOKEN` is valid and not expired |
| Config.js returns empty | Ensure env vars are set in App Settings |
| Port binding fails | Check PORT env var, ensure 3000 is open |
| React Router broken | serve-dist.mjs has SPA fallback, should work |
| Build takes too long | npm ci caches in layer 2; clean build is normal first time |

