# Environment Variables Analysis - Runtime Only Configuration

## Current Status: ❌ NOT Runtime-Only

Your codebase has **hardcoded fallback defaults** that will be used if environment variables are not provided.

---

## Issues Found

### 1. **Hardcoded Defaults in src/lib/apiClient.ts** ⚠️

```typescript
// Line 23-26
export const AUTH_BASE = rstrip(
  runtimeEnv(
    "VITE_AUTH_API_BASE_URL",
    import.meta.env.VITE_AUTH_API_BASE_URL,
    "http://localhost:4000",  // ← DEFAULT FALLBACK
  ),
);

// Line 32-35
export const API_BASE = rstrip(
  runtimeEnv(
    "VITE_AGENTIC_API_BASE_URL",
    import.meta.env.VITE_AGENTIC_API_BASE_URL,
    "http://localhost:8000",  // ← DEFAULT FALLBACK
  ),
);
```

**Problem**: If neither runtime config (`window.__RUNTIME_CONFIG__`), build-time env, nor process.env provides these values, the app will fall back to:
- `AUTH_BASE` = `http://localhost:4000` (dev server)
- `API_BASE` = `http://localhost:8000` (dev server)

This is **NOT suitable for production Docker deployment**.

---

## Resolution Order (Current)

The `runtimeEnv()` function checks in this order:

```
1. window.__RUNTIME_CONFIG__[key]     (from /config.js at runtime)
2. import.meta.env.VITE_*              (baked in at build time)
3. fallback value (localhost defaults) (⚠️ fallback exists!)
```

---

## What Needs to Change

### Option 1: Remove Fallbacks Entirely (Recommended) ✅

Make environment variables **mandatory** - fail if not provided:

```typescript
// src/lib/apiClient.ts

export const AUTH_BASE = rstrip(
  runtimeEnv(
    "VITE_AUTH_API_BASE_URL",
    import.meta.env.VITE_AUTH_API_BASE_URL,
    // NO FALLBACK - will be empty string if not provided
  ),
);

export const API_BASE = rstrip(
  runtimeEnv(
    "VITE_AGENTIC_API_BASE_URL",
    import.meta.env.VITE_AGENTIC_API_BASE_URL,
    // NO FALLBACK - will be empty string if not provided
  ),
);
```

Then add validation to throw errors:

```typescript
if (!AUTH_BASE) {
  throw new Error(
    'Missing AUTH_API_BASE_URL environment variable. ' +
    'Set via: docker run -e AUTH_API_BASE_URL=https://...'
  );
}
if (!API_BASE) {
  throw new Error(
    'Missing AGENTIC_API_BASE_URL environment variable. ' +
    'Set via: docker run -e AGENTIC_API_BASE_URL=https://...'
  );
}
```

### Option 2: Add Initialization Check ✅

Create an init function that validates all required env vars before app starts:

```typescript
export function validateRuntimeConfig() {
  const config = getRuntimeConfig();
  const required = [
    'VITE_AUTH_API_BASE_URL',
    'VITE_AGENTIC_API_BASE_URL'
  ];
  
  for (const key of required) {
    if (!config[key as keyof RuntimeConfig]) {
      throw new Error(
        `Required environment variable missing: ${key}\n` +
        `Deploy with: docker run -e ${key}=https://your-api.com ...`
      );
    }
  }
}
```

Call in main.tsx:

```typescript
import { validateRuntimeConfig } from '@/lib/runtimeConfig';

validateRuntimeConfig(); // Throws error if env vars missing

ReactDOM.createRoot(document.getElementById("root")!).render(
  <App />
);
```

---

## Complete Fix Steps

### Step 1: Update src/lib/apiClient.ts

Remove the fallback defaults:

```typescript
// BEFORE
export const AUTH_BASE = rstrip(
  runtimeEnv(
    "VITE_AUTH_API_BASE_URL",
    import.meta.env.VITE_AUTH_API_BASE_URL,
    "http://localhost:4000",  // ← REMOVE THIS
  ),
);

// AFTER
export const AUTH_BASE = rstrip(
  runtimeEnv(
    "VITE_AUTH_API_BASE_URL",
    import.meta.env.VITE_AUTH_API_BASE_URL,
    // No fallback
  ),
);
```

### Step 2: Update src/lib/runtimeConfig.ts

Add validation function:

```typescript
export function validateRuntimeConfig(): void {
  const config = getRuntimeConfig();
  const required: (keyof RuntimeConfig)[] = [
    'VITE_AUTH_API_BASE_URL',
    'VITE_AGENTIC_API_BASE_URL'
  ];
  
  const missing: string[] = [];
  for (const key of required) {
    const value = config[key];
    if (!value || value.trim() === '') {
      missing.push(key);
    }
  }
  
  if (missing.length > 0) {
    const envVarHints = missing
      .map(k => `-e ${k}=https://api.your-domain.com`)
      .join(' ');
    
    throw new Error(
      `Missing required environment variables: ${missing.join(', ')}\n\n` +
      `When running in Docker, provide them:\n` +
      `  docker run ${envVarHints} claims-frontend:latest\n\n` +
      `Or in Azure App Services:\n` +
      `  Configuration → Application Settings → add the above variables`
    );
  }
}
```

### Step 3: Update src/main.tsx

Call validation on app startup:

```typescript
import { validateRuntimeConfig } from '@/lib/runtimeConfig';

// Validate environment before app initializes
if (typeof window !== 'undefined') {
  try {
    validateRuntimeConfig();
  } catch (error) {
    console.error(error);
    document.body.innerHTML = `
      <div style="padding: 20px; font-family: monospace; white-space: pre-wrap;">
        <h1>Configuration Error</h1>
        ${error instanceof Error ? error.message : 'Unknown error'}
      </div>
    `;
    throw error;
  }
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <App />
);
```

### Step 4: Update Dockerfile

Ensure no env vars are set as defaults in Dockerfile:

```dockerfile
# NO env vars for API URLs - must be provided at runtime
ENV NODE_ENV=production \
    PORT=3000 \
    HOST=0.0.0.0
# Not in Dockerfile: AUTH_API_BASE_URL, AGENTIC_API_BASE_URL
```

### Step 5: Update Documentation

Update DOCKER_QUICKSTART.md to show env vars are **required**:

```bash
# ✅ REQUIRED - will fail without these:
docker run \
  -e AUTH_API_BASE_URL="https://claims-api-uat.optum.com" \
  -e AGENTIC_API_BASE_URL="https://agentic-uat.optum.com" \
  -p 3000:3000 \
  claims-frontend:latest
```

---

## Summary Table

| Component | Current | Issue | Fix |
|-----------|---------|-------|-----|
| `AUTH_BASE` | Falls back to `http://localhost:4000` | Not runtime-only | Remove fallback |
| `API_BASE` | Falls back to `http://localhost:8000` | Not runtime-only | Remove fallback |
| Validation | None | Can start without config | Add init check |
| Docker | No required env vars | Unclear what's needed | Document as required |

---

## Testing After Fix

### Should FAIL (good):
```bash
docker run -p 3000:3000 claims-frontend:latest
# Error: Missing required environment variables: VITE_AUTH_API_BASE_URL, VITE_AGENTIC_API_BASE_URL
```

### Should SUCCEED (good):
```bash
docker run \
  -e AUTH_API_BASE_URL="https://api.example.com" \
  -e AGENTIC_API_BASE_URL="https://agentic.example.com" \
  -p 3000:3000 \
  claims-frontend:latest
# App starts successfully
```

---

## Current Files That Need Changes

1. ✏️ **src/lib/apiClient.ts** - Remove fallbacks
2. ✏️ **src/lib/runtimeConfig.ts** - Add validation
3. ✏️ **src/main.tsx** - Call validation on startup
4. ✏️ **Dockerfile** - Remove any API URL defaults
5. 📝 **DOCKER_QUICKSTART.md** - Mark env vars as required

