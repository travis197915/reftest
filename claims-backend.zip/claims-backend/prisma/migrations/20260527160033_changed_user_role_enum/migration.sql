/*
  Warnings:

  - The values [MEMBER] on the enum `UserRole` will be removed. If these variants are still used in the database, this will fail.
  - You are about to drop the `work_area` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workbench` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workbench_agent` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workbench_connection` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workbench_run` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workflow` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `workflow_run` table. If the table is not empty, all the data it contains will be lost.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "UserRole_new" AS ENUM ('ADMIN', 'AUDITOR');
ALTER TABLE "app_user" ALTER COLUMN "role" DROP DEFAULT;
ALTER TABLE "app_user" ALTER COLUMN "role" TYPE "UserRole_new" USING ("role"::text::"UserRole_new");
ALTER TYPE "UserRole" RENAME TO "UserRole_old";
ALTER TYPE "UserRole_new" RENAME TO "UserRole";
DROP TYPE "UserRole_old";
ALTER TABLE "app_user" ALTER COLUMN "role" SET DEFAULT 'AUDITOR';
COMMIT;

-- DropForeignKey
ALTER TABLE "work_area" DROP CONSTRAINT "work_area_workflow_id_fkey";

-- DropForeignKey
ALTER TABLE "workbench" DROP CONSTRAINT "workbench_work_area_id_fkey";

-- DropForeignKey
ALTER TABLE "workbench_agent" DROP CONSTRAINT "workbench_agent_workbench_id_fkey";

-- DropForeignKey
ALTER TABLE "workbench_connection" DROP CONSTRAINT "workbench_connection_from_workbench_id_fkey";

-- DropForeignKey
ALTER TABLE "workbench_connection" DROP CONSTRAINT "workbench_connection_to_workbench_id_fkey";

-- DropForeignKey
ALTER TABLE "workbench_run" DROP CONSTRAINT "workbench_run_workbench_id_fkey";

-- DropForeignKey
ALTER TABLE "workbench_run" DROP CONSTRAINT "workbench_run_workflow_run_id_fkey";

-- DropForeignKey
ALTER TABLE "workflow_run" DROP CONSTRAINT "workflow_run_workflow_id_fkey";

-- AlterTable
ALTER TABLE "app_user" ALTER COLUMN "role" SET DEFAULT 'AUDITOR';

-- DropTable
DROP TABLE "work_area";

-- DropTable
DROP TABLE "workbench";

-- DropTable
DROP TABLE "workbench_agent";

-- DropTable
DROP TABLE "workbench_connection";

-- DropTable
DROP TABLE "workbench_run";

-- DropTable
DROP TABLE "workflow";

-- DropTable
DROP TABLE "workflow_run";
