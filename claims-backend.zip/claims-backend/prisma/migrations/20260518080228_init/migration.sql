-- CreateEnum
CREATE TYPE "BenchType" AS ENUM ('TRIGGER', 'ACTION', 'CONDITION', 'OUTPUT');

-- CreateEnum
CREATE TYPE "RunStatus" AS ENUM ('PENDING', 'RUNNING', 'COMPLETED', 'FAILED');

-- CreateEnum
CREATE TYPE "WorkbenchRunStatus" AS ENUM ('RUNNING', 'COMPLETED', 'SKIPPED', 'FAILED');

-- CreateTable
CREATE TABLE "workflow" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT '',
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "workflow_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "work_area" (
    "id" TEXT NOT NULL,
    "workflow_id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT '',
    "order" INTEGER NOT NULL DEFAULT 0,
    "color" TEXT NOT NULL DEFAULT '',
    "position_x" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "position_y" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "width" DOUBLE PRECISION NOT NULL DEFAULT 1200,
    "height" DOUBLE PRECISION NOT NULL DEFAULT 800,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "work_area_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "workbench" (
    "id" TEXT NOT NULL,
    "work_area_id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT '',
    "node_key" TEXT NOT NULL DEFAULT '',
    "bench_type" "BenchType" NOT NULL,
    "config" JSONB NOT NULL DEFAULT '{}',
    "order" INTEGER NOT NULL DEFAULT 0,
    "position_x" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "position_y" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "width" DOUBLE PRECISION NOT NULL DEFAULT 160,
    "height" DOUBLE PRECISION NOT NULL DEFAULT 80,
    "style" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "workbench_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "workbench_agent" (
    "id" TEXT NOT NULL,
    "workbench_id" TEXT NOT NULL,
    "agent_name" TEXT NOT NULL,
    "order" INTEGER NOT NULL DEFAULT 0,
    "config" JSONB NOT NULL DEFAULT '{}',
    "input_mapping" JSONB NOT NULL DEFAULT '{}',
    "output_mapping" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "workbench_agent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "workbench_connection" (
    "id" TEXT NOT NULL,
    "from_workbench_id" TEXT NOT NULL,
    "to_workbench_id" TEXT NOT NULL,
    "condition_label" TEXT NOT NULL DEFAULT '',
    "label" TEXT NOT NULL DEFAULT '',
    "waypoints" JSONB NOT NULL DEFAULT '[]',
    "style" JSONB NOT NULL DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "workbench_connection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "workflow_run" (
    "id" TEXT NOT NULL,
    "workflow_id" TEXT NOT NULL,
    "status" "RunStatus" NOT NULL DEFAULT 'PENDING',
    "context" JSONB NOT NULL DEFAULT '{}',
    "error" TEXT NOT NULL DEFAULT '',
    "started_at" TIMESTAMP(3),
    "completed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "workflow_run_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "workbench_run" (
    "id" TEXT NOT NULL,
    "workflow_run_id" TEXT NOT NULL,
    "workbench_id" TEXT NOT NULL,
    "status" "WorkbenchRunStatus" NOT NULL DEFAULT 'RUNNING',
    "inputs" JSONB NOT NULL DEFAULT '{}',
    "outputs" JSONB NOT NULL DEFAULT '{}',
    "started_at" TIMESTAMP(3),
    "completed_at" TIMESTAMP(3),

    CONSTRAINT "workbench_run_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "workflow_slug_key" ON "workflow"("slug");

-- CreateIndex
CREATE INDEX "workflow_is_active_idx" ON "workflow"("is_active");

-- CreateIndex
CREATE INDEX "work_area_workflow_id_order_idx" ON "work_area"("workflow_id", "order");

-- CreateIndex
CREATE INDEX "workbench_work_area_id_order_idx" ON "workbench"("work_area_id", "order");

-- CreateIndex
CREATE INDEX "workbench_work_area_id_bench_type_idx" ON "workbench"("work_area_id", "bench_type");

-- CreateIndex
CREATE INDEX "workbench_node_key_idx" ON "workbench"("node_key");

-- CreateIndex
CREATE INDEX "workbench_agent_workbench_id_order_idx" ON "workbench_agent"("workbench_id", "order");

-- CreateIndex
CREATE INDEX "workbench_connection_from_workbench_id_idx" ON "workbench_connection"("from_workbench_id");

-- CreateIndex
CREATE INDEX "workbench_connection_to_workbench_id_idx" ON "workbench_connection"("to_workbench_id");

-- CreateIndex
CREATE INDEX "workflow_run_workflow_id_created_at_idx" ON "workflow_run"("workflow_id", "created_at");

-- CreateIndex
CREATE INDEX "workbench_run_workflow_run_id_idx" ON "workbench_run"("workflow_run_id");

-- AddForeignKey
ALTER TABLE "work_area" ADD CONSTRAINT "work_area_workflow_id_fkey" FOREIGN KEY ("workflow_id") REFERENCES "workflow"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workbench" ADD CONSTRAINT "workbench_work_area_id_fkey" FOREIGN KEY ("work_area_id") REFERENCES "work_area"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workbench_agent" ADD CONSTRAINT "workbench_agent_workbench_id_fkey" FOREIGN KEY ("workbench_id") REFERENCES "workbench"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workbench_connection" ADD CONSTRAINT "workbench_connection_from_workbench_id_fkey" FOREIGN KEY ("from_workbench_id") REFERENCES "workbench"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workbench_connection" ADD CONSTRAINT "workbench_connection_to_workbench_id_fkey" FOREIGN KEY ("to_workbench_id") REFERENCES "workbench"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workflow_run" ADD CONSTRAINT "workflow_run_workflow_id_fkey" FOREIGN KEY ("workflow_id") REFERENCES "workflow"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workbench_run" ADD CONSTRAINT "workbench_run_workflow_run_id_fkey" FOREIGN KEY ("workflow_run_id") REFERENCES "workflow_run"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "workbench_run" ADD CONSTRAINT "workbench_run_workbench_id_fkey" FOREIGN KEY ("workbench_id") REFERENCES "workbench"("id") ON DELETE CASCADE ON UPDATE CASCADE;
