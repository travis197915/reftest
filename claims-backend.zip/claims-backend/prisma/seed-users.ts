/**
 * Seed script for HITL / UAT users.
 *
 * Source: "UAT HITL Users" sheet (name, role, email).
 * Run with:  npx tsx prisma/seed-users.ts
 *
 * Idempotent by email. Each run assigns every user a fresh, unique password
 * that contains the text "optum". The generated credentials are printed to the
 * console so they can be distributed — copy them before closing the terminal.
 */
import { randomInt } from "node:crypto";
import { PrismaClient, UserRole } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const BCRYPT_ROUNDS = 10;

/**
 * Build a unique, human-typable password that contains the literal "optum".
 * Shape: "Optum-<word>-<4 digits>", e.g. "Optum-amber-4821".
 */
function generatePassword(used: Set<string>): string {
  for (let attempt = 0; attempt < 1000; attempt += 1) {
    const digits = String(randomInt(1000, 10000));
    const candidate = `Optum-${digits}`;
    if (!used.has(candidate)) {
      used.add(candidate);
      return candidate;
    }
  }
  throw new Error("Unable to generate a unique password");
}

type SeedUser = {
  name: string;
  role: UserRole;
  email: string;
};

const USERS: SeedUser[] = [
  { name: "Taniya Davis", role: UserRole.ADMIN, email: "taniya.davis@optum.com" },
  { name: "Wendy Vietz", role: UserRole.AUDITOR, email: "wendy.vietz@optum.com" },
  { name: "Elymar Rios", role: UserRole.AUDITOR, email: "elymar.rios@optum.com" },
  { name: "Alana Bagley", role: UserRole.AUDITOR, email: "alana.bagley@optum.com" },
  { name: "Sandra Lopez", role: UserRole.AUDITOR, email: "sandra.soto@optum.com" },
  { name: "Anil Balani", role: UserRole.ADMIN, email: "anil_balani1@optum.com" },
  { name: "Upendra Banala", role: UserRole.ADMIN, email: "upendra_banala@optum.com" },
  { name: "Jarod Derrick", role: UserRole.ADMIN, email: "jarod_derrick@optum.com" },
  { name: "Stalinson Thdamalla", role: UserRole.ADMIN, email: "stalinson_thadamalla1@optum.com" },
  { name: "Shari Laporte", role: UserRole.ADMIN, email: "shari.laporte@optum.com" },
  { name: "Erin Blood", role: UserRole.ADMIN, email: "erin_blood@uhc.com" },
  { name: "Kirti Deshmukh", role: UserRole.ADMIN, email: "kirti_deshmukh@optum.com" },
];

async function main() {
  const usedPasswords = new Set<string>();
  const credentials: Array<{ email: string; role: UserRole; password: string }> = [];

  let created = 0;
  let updated = 0;

  for (const u of USERS) {
    const email = u.email.trim().toLowerCase();
    const password = generatePassword(usedPasswords);
    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);

    const result = await prisma.user.upsert({
      where: { email },
      create: {
        email,
        name: u.name,
        role: u.role,
        passwordHash,
        isActive: true,
      },
      update: {
        name: u.name,
        role: u.role,
        passwordHash,
        isActive: true,
      },
      select: { createdAt: true, updatedAt: true },
    });

    const isNew = result.createdAt.getTime() === result.updatedAt.getTime();
    if (isNew) created += 1;
    else updated += 1;
    credentials.push({ email, role: u.role, password });
    console.log(`${isNew ? "created" : "updated"}  ${u.role.padEnd(7)}  ${email}`);
  }

  console.log(`\nDone. ${created} created, ${updated} updated, ${USERS.length} total.`);
  console.log("\nCredentials (distribute securely, then discard):");
  const emailWidth = Math.max(...credentials.map((c) => c.email.length));
  for (const c of credentials) {
    console.log(`  ${c.email.padEnd(emailWidth)}  ${c.role.padEnd(7)}  ${c.password}`);
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
