# Ingest APIs (proxied)

Implemented in Django (`uhc-agentic-backend`). This relay forwards them unchanged under
`/api/ingest` (see `INGEST_PROXY_ROUTES` in `src/routes/proxy.ts`).

**Base URL (SPA):** `http://localhost:4000` (or your relay host)  
**Auth:** `Authorization: Bearer <jwt>` on every call  
**Write access:** `POST` requires `ADMIN`; `GET` allowed for `AUDITOR` (`requireWriteAccess`)

Trailing slashes are optional on Django; both forms work upstream.

---

## 1. List versions

`GET /api/ingest/documents/{document_id}/versions/`

| Param         | Location | Required | Description      |
| ------------- | -------- | -------- | ---------------- |
| `document_id` | path     | yes      | SopDocument PK   |

Query params: none

**Response (main fields):** `document_id`, `canonical_url`, `title`, `latest_revision_date`,
`current_sop_id`, `pending_review_count`, `pending_review_sop_ids[]`, `versions[]`
(`sop_id`, `job_id`, `version_number`, `is_current`, `activation_status`, `version_action`,
`revision_date`, `effective_date`, `content_hash`, `supersedes_sop_id`, `crawled_at`)

---

## 2. Affected workflows

`GET /api/ingest/documents/{document_id}/affected-workflows/`  
(also works without trailing `/`)

| Param         | Location | Required | Description                                      |
| ------------- | -------- | -------- | ------------------------------------------------ |
| `document_id` | path     | yes      | SopDocument PK                                   |
| `sop_id`      | query    | no       | Filter bindings to one AuditSop (same document)  |
| `current_only`| query    | no       | `1` / `true` / `yes` — only `sop.is_current=true`|

**Response (main fields):** `document_id`, `canonical_url`, `title`, `current_sop_id`,
`current_revision_date`, `summary` (`workflow_count`, `rule_binding_count`, …), `workflows[]`
(per workflow: `workflow_id`, `shapes[]`, `bound_sop_versions[]`, `ingestion_jobs[]`,
`needs_rebind_after_version_change`, …)

**Errors:** `400` if `sop_id` not an integer; `404` if `sop_id` not found for document

---

## 3. Revision check (one document)

`POST /api/ingest/documents/{document_id}/revision-check/`  
(also without trailing `/`)

| Param         | Location | Required | Default | Description                                      |
| ------------- | -------- | -------- | ------- | ------------------------------------------------ |
| `document_id` | path     | yes      | —       | SopDocument PK                                   |
| `dry_run`     | query    | no       | `false` | `1`/`true`/`yes` — probe only, no re-ingest job  |
| `async`       | query    | no       | `false` | `1`/`true`/`yes` — run via Celery (`202`)        |
| `force`       | query    | no       | `false` | `1`/`true`/`yes` — fail blocking QUEUED/RUNNING job and queue re-ingest |

Body: none

### Inline `200` (when `async=0`)

| Field | When |
| ----- | ---- |
| `status` | `unchanged` \| `changed` \| `queued` \| `skipped_active_job` \| `error` |
| `has_deviation` | `true` if remote differs from stored |
| `version_action` | `unchanged` \| `revised` \| `content_change` |
| `remote_revision_date`, `stored_revision_date`, `remote_content_hash`, `stored_content_hash` | always (except `error`) |
| `job_id`, `celery_task_id`, `requires_human_review`, `message` | when `status=queued` |
| `blocking_job_id`, `blocking_job_status`, `message` | when `status=skipped_active_job` |
| `expired_blocking_job_id` | when a stale blocking job was auto-failed |
| `error` | when `status=error` (`502`) |

### Async `202`

`document_id`, `dispatched`, `dry_run`, `force`, `celery_task_id`

---

## 4. Revision check (batch)

`POST /api/ingest/revision-check/`  
(also without trailing `/`)

| Param    | Location | Required | Default | Description |
| -------- | -------- | -------- | ------- | ----------- |
| `async`  | query    | no       | `true`  | `1`/`true`/`yes` — Celery task; `0`/`false` runs inline |
| `dry_run`| query    | no       | `false` | `1`/`true`/`yes` — probe only, no jobs queued |

Body: none

**Inline `200`:** `{ "summary": { checked, unchanged, changed, queued, skipped_active_job, errors }, "results": [ … per-URL items like #3 ] }`

**Async `202`** (when `async=1` and not `dry_run`): `dispatched`, `dry_run`, `celery_task_id`

Note: `async=1` + `dry_run=1` runs batch inline (probe only), still `200`.

---

## 5. Version diff

`GET /api/ingest/sops/{sop_id}/diff/`  
(also without trailing `/`)

| Param   | Location | Required | Description              |
| ------- | -------- | -------- | ------------------------ |
| `sop_id`| path     | yes      | AuditSop PK (the “to” version) |

Query params: none

**Response:** `has_diff` (`false` → empty `summary`/`changes`); if `true`: `from_sop_id`,
`to_sop_id`, `from_revision_date`, `to_revision_date`, `from_content_hash`, `to_content_hash`,
`version_action`, `summary`, `changes[]`, `computed_at`

---

## 6. Activate version

`POST /api/ingest/sops/{sop_id}/activate/`  
(also without trailing `/`)

| Param   | Location | Required | Description |
| ------- | -------- | -------- | ----------- |
| `sop_id`| path     | yes      | AuditSop with `activation_status=pending_review` |

**JSON body (optional):**

| Field         | Type   | Required | Description           |
| ------------- | ------ | -------- | --------------------- |
| `reviewed_by` | string | no       | Auditor id/email for logs |

**Response `200`:** `sop_id`, `document_id`, `version_number`, `is_current`, `activation_status`, `revision_date`

**Errors:** `409` if not `pending_review` or not linked to a document

---

## 7. Reject version

`POST /api/ingest/sops/{sop_id}/reject/`  
(also without trailing `/`)

| Param   | Location | Required | Description |
| ------- | -------- | -------- | ----------- |
| `sop_id`| path     | yes      | AuditSop with `activation_status=pending_review` |

**JSON body (optional):**

| Field         | Type   | Required | Description        |
| ------------- | ------ | -------- | ------------------ |
| `reviewed_by` | string | no       | Reviewer id/email  |
| `reason`      | string | no       | Rejection reason   |

**Response `200`:** `sop_id`, `document_id`, `version_number`, `is_current`, `activation_status`

**Errors:** `409` if not `pending_review`

---

## Related — job polling

`GET /api/ingest/{job_id}/`

| Param   | Location | Required | Description                          |
| ------- | -------- | -------- | ------------------------------------ |
| `job_id`| path     | yes      | UUID from revision-check `job_id`    |

---

## Example calls (via relay)

```bash
# Versions
GET /api/ingest/documents/42/versions/

# Affected workflows (current bindings only)
GET /api/ingest/documents/42/affected-workflows/?current_only=1

# Probe one doc, queue re-ingest
POST /api/ingest/documents/42/revision-check/?force=1

# Probe only
POST /api/ingest/documents/42/revision-check/?dry_run=1

# Batch async
POST /api/ingest/revision-check/?async=1

# Diff + activate
GET  /api/ingest/sops/901/diff/
POST /api/ingest/sops/901/activate/
Content-Type: application/json
{"reviewed_by": "auditor@example.com"}
```
