# Execution APIs (proxied)

Implemented in Django (`uhc-agentic-backend`, `execution_app`). This relay forwards them
unchanged under `/api/execute` and `/api/claims` (see `EXECUTION_PROXY_ROUTES` in
`src/routes/proxy.ts`).

**Base URL (SPA):** `http://localhost:4000` (or your relay host)  
**Auth:** `Authorization: Bearer <jwt>` on every call  
**Write access:** `POST` / `PATCH` require `ADMIN`; `GET` allowed for `AUDITOR` (`requireWriteAccess`)

Trailing slashes are optional on Django; both forms work upstream.

---

## Set human review status

### By run ID

`PATCH /api/execute/runs/{run_id}/review-status/`  
(also without trailing `/`)

| Param   | Location | Required | Description   |
| ------- | -------- | -------- | ------------- |
| `run_id`| path     | yes      | Workflow run UUID |

**Headers:** `Content-Type: application/json`

**Request body:**

```json
{ "reviewStatus": "in_progress" }
```

Also accepts `review_status` (snake_case). Hyphens are normalized (`in-progress` → `in_progress`).

| `reviewStatus` | Meaning                    |
| -------------- | -------------------------- |
| `pending`      | Waiting for auditor        |
| `in_progress`  | Auditor actively reviewing |
| `completed`    | Review done                |

---

### By claim ID

`PATCH /api/claims/{claim_id}/review-status/`  
(also without trailing `/`)

| Param     | Location | Required | Description              |
| --------- | -------- | -------- | ------------------------ |
| `claim_id`| path     | yes      | Claim identifier         |
| `run_id`  | query    | no       | Target a specific run UUID |
| `batch_id`| query    | no       | Scope lookup to one batch |

**Headers:** `Content-Type: application/json`

**Request body:** same as run route (`reviewStatus` / `review_status`, same allowed values).

---

## Approve / reject claim review

### Approve

`POST /api/claims/{claim_id}/review/approve/`  
(also without trailing `/`)

| Param      | Location | Required | Description      |
| ---------- | -------- | -------- | ---------------- |
| `claim_id` | path     | yes      | Claim identifier |

**Headers:** `Content-Type: application/json`

**Request body (optional feedback):**

```json
{ "feedback": "Approved after manual review" }
```

### Reject

`POST /api/claims/{claim_id}/review/reject/`  
(also without trailing `/`)

| Param      | Location | Required | Description      |
| ---------- | -------- | -------- | ---------------- |
| `claim_id` | path     | yes      | Claim identifier |

**Headers:** `Content-Type: application/json`

**Request body (`feedback` required):**

```json
{ "feedback": "Deny — insufficient evidence" }
```

---

## Example calls (via relay)

```bash
# By run
curl -X PATCH "http://localhost:4000/api/execute/runs/RUN_UUID/review-status/" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"reviewStatus": "in_progress"}'

# By claim (optional run/batch scope)
curl -X PATCH "http://localhost:4000/api/claims/CLAIM_ID/review-status/?run_id=RUN_UUID" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"review_status": "completed"}'

# Approve
curl -X POST "http://localhost:4000/api/claims/25XJ16631800/review/approve/" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"feedback": "Approved after manual review"}'

# Reject (feedback required)
curl -X POST "http://localhost:4000/api/claims/25XJ16631800/review/reject/" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"feedback": "Deny — insufficient evidence"}'
```

---

## Other execution routes (catalog)

| Method | Path | Notes |
| ------ | ---- | ----- |
| POST | `/api/execute/workflows/:workflowId/run-batch/` | Sync batch run |
| POST | `/api/execute/workflows/:workflowId/run-batch-async/` | Async batch run |
| GET | `/api/execute/batches/latest/` | Latest batch |
| GET | `/api/execute/batches/:batchId/` | Batch status |
| GET | `/api/execute/batches/:batchId/events/` | SSE progress (streaming proxy) |
| GET | `/api/execute/runs/` | List runs |
| GET | `/api/execute/runs/:runId/` | Run detail |
| GET | `/api/execute/runs/:runId/nodes/` | Run node audit |
| GET | `/api/claims/:claimId/processing/` | Claim processing snapshot |
| PATCH | `/api/claims/:claimId/review-status/` | Set human review status |
| POST | `/api/claims/:claimId/review/approve/` | Approve claim; optional `{ feedback }` |
| POST | `/api/claims/:claimId/review/reject/` | Reject claim; `{ feedback }` required |
