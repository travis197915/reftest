# claims-corebackend

The **Node relay** for the UHC claims platform. The React frontend talks only to
this service — never to Django directly.

Three responsibilities:

1. **Identity** — register, login, JWT minting, user admin (Prisma + Postgres)
2. **BFF** — orchestrate multi-call responses the SPA needs (`/api/dashboard/stats`)
3. **Proxy** — forward authenticated requests to Django (`uhc-agentic-backend`)

Both Node and Django share the same `JWT_SECRET`, so a token minted here grants
access to proxied builder, ingest, and agent-tools routes on the Django side.

**Stack:** Node 20 · TypeScript (ESM, `NodeNext`) · Express 4 · Prisma 5 ·
PostgreSQL · Zod · bcryptjs · jsonwebtoken · http-proxy-middleware · winston.

---

## Architecture

```
React SPA  (uhc-claims-frontend)
      │  REST + Authorization: Bearer <jwt>
      ▼
claims-corebackend  (this repo, port 4000)
      │
      ├─ Node-owned handlers
      │    /auth/*           Prisma — register, login, me, change-password
      │    /api/users/*      Prisma — admin user list / role / status
      │    /api/dashboard/*  BFF — aggregates Django data for the SPA
      │
      └─ Proxy (http-proxy-middleware → DJANGO_BASE_URL)
           /api/builder/*       catalog, UI chrome, workflows, canvas CRUD
           /api/ingest/*        SOP ingestion jobs + graph/sections
           /api/execute/*       batch adjudication + run audit (SSE on …/events/)
           /api/claims/*        claim processing snapshot (SPA contract)
           /api/agent-tools/*   tool registry
           /api/agents/*        agent registry
           /api/combo-templates/*
           /license/*
      ▼
Django  (uhc-agentic-backend / sop_backend, port 8000)
```

Node-owned routes are registered **before** the proxy in `src/routes/index.ts`,
so they take precedence over pass-through paths.

Proxy errors from Django are normalized into a consistent JSON envelope
(`{ error, details?, source: "django" }`) before reaching the frontend.

---

## Features

### Authentication & JWT

- `POST /auth/register` — `{ email, password, name? }` → `201 { token, user }`
- `POST /auth/login` — `{ email, password }` → `200 { token, user }` or generic `401`
- `GET /auth/me` — current user (Bearer required)
- `POST /auth/change-password` — `{ currentPassword, newPassword }`
- HS256 tokens via `JWT_SECRET` (≥ 16 chars); lifetime from `JWT_EXPIRES_IN` (default `7d`)
- Claims: `{ sub, email, role }` — Django resolves the user from `sub`
- First registered user auto-promoted to `ADMIN` when `BOOTSTRAP_ADMIN=true` (default)

### User management (admin)

All routes require `requireAuth` + `requireAdmin`:

| Method | Path                    | Body / query              |
| ------ | ----------------------- | ------------------------- |
| GET    | `/api/users/`           | `?cursor&limit&search`    |
| GET    | `/api/users/:id`        | —                         |
| PATCH  | `/api/users/:id/role`   | `{ role: "ADMIN"\|"MEMBER" }` |
| PATCH  | `/api/users/:id/status` | `{ isActive: boolean }`   |

### Dashboard BFF

| Method | Path                   | Notes                                              |
| ------ | ---------------------- | -------------------------------------------------- |
| GET    | `/api/dashboard/stats` | Aggregates agent + workflow counts from Django     |

Implemented in `services/dashboard.ts` using `djangoClient` (server-side fetch
with the caller's JWT forwarded).

### Django proxy

Every proxied mount requires a valid Bearer token. The proxy:

- Re-prefixes the mount path so Django receives the full URL
  (e.g. `/api/builder/ui/navigation/`)
- Forwards the `Authorization` header unchanged
- Normalizes upstream 4xx/5xx into the relay error envelope
- Returns `502` when Django is unreachable

### Health, logging, errors

- `GET /health` — public `{ status: "ok" }`
- Request logging with per-request IDs (`middleware/requestLogger.ts`)
- Structured logging via winston (`utils/logger.ts`)
- Central error handler for Node routes: `HttpError`, Zod, Prisma, JSON parse errors
- JSON body limit: **16 MB** (supports large graph saves)

---

## REST surface

### Node-owned

| Method | Path                       | Auth     | Notes                          |
| ------ | -------------------------- | -------- | ------------------------------ |
| GET    | `/health`                  | public   | Liveness probe                 |
| POST   | `/auth/register`           | public   |                                |
| POST   | `/auth/login`              | public   |                                |
| GET    | `/auth/me`                 | Bearer   |                                |
| POST   | `/auth/change-password`    | Bearer   |                                |
| GET    | `/api/users/`              | Admin    | Paginated user list            |
| GET    | `/api/users/:id`           | Admin    |                                |
| PATCH  | `/api/users/:id/role`      | Admin    |                                |
| PATCH  | `/api/users/:id/status`    | Admin    |                                |
| GET    | `/api/dashboard/stats`     | Bearer   | BFF aggregation                |

### Proxied to Django (all require Bearer)

| Mount path              | Django domain                                          |
| ----------------------- | ------------------------------------------------------ |
| `/api/builder/*`        | Catalog, navigation, **workflows**, graph save, attach |
| `/api/ingest/*`         | Ingestion jobs, SOP graph/sections, **versioning** ([docs/Ingest APIs.md](docs/Ingest%20APIs.md)) |
| `/api/execute/*`        | Batch run, batches, runs, SSE, **review-status** ([docs/Execution APIs.md](docs/Execution%20APIs.md)) |
| `/api/claims/*`         | Claim processing, **review-status**, **approve/reject** ([docs/Execution APIs.md](docs/Execution%20APIs.md)) |
| `/api/agent-tools/*`    | Tool registry                                          |
| `/api/agents/*`         | Agent registry                                         |
| `/api/combo-templates/*`| Combo templates                                        |
| `/license/*`            | License endpoints                                      |

Any unmatched path returns `404 { error: "Not found", source: "relay" }`.

#### Ingest — SOP versioning (`INGEST_PROXY_ROUTES`)

| Method | Path | Notes |
| ------ | ---- | ----- |
| GET | `/api/ingest/documents/:document_id/versions/` | Version list for a SopDocument |
| GET | `/api/ingest/documents/:document_id/affected-workflows/` | Workflows bound to the document; `?sop_id=`, `?current_only=1` |
| POST | `/api/ingest/documents/:document_id/revision-check/` | Single-doc revision probe/queue; `?dry_run`, `?async`, `?force` |
| POST | `/api/ingest/revision-check/` | Batch revision check; `?async` (default true), `?dry_run` |
| GET | `/api/ingest/sops/:sop_id/diff/` | Diff vs prior version |
| POST | `/api/ingest/sops/:sop_id/activate/` | Activate `pending_review` version; optional `{ reviewed_by }` |
| POST | `/api/ingest/sops/:sop_id/reject/` | Reject `pending_review` version; optional `{ reviewed_by, reason }` |
| GET | `/api/ingest/:job_id/` | Poll job after revision-check |

Full field-level contracts: [docs/Ingest APIs.md](docs/Ingest%20APIs.md).

#### Execution — human review (`EXECUTION_PROXY_ROUTES`)

| Method | Path | Notes |
| ------ | ---- | ----- |
| PATCH | `/api/execute/runs/:run_id/review-status/` | Body: `{ "reviewStatus": "pending" \| "in_progress" \| "completed" }` |
| PATCH | `/api/claims/:claim_id/review-status/` | Same body; optional `?run_id=`, `?batch_id=` |
| POST | `/api/claims/:claim_id/review/approve/` | Optional `{ "feedback": "…" }` |
| POST | `/api/claims/:claim_id/review/reject/` | Required `{ "feedback": "…" }` |

Also accepts `review_status` (snake_case); hyphens normalized (`in-progress` → `in_progress`).  
Full contracts: [docs/Execution APIs.md](docs/Execution%20APIs.md).

The `user` projection from auth endpoints:

```json
{
  "id": "ckxyz…",
  "email": "user@example.com",
  "name": "Display Name",
  "role": "ADMIN",
  "isActive": true,
  "createdAt": "2026-05-19T..."
}
```

---

## Configuration

Copy `.env.example` → `.env`:

| Var               | Default                                           | Notes                                           |
| ----------------- | ------------------------------------------------- | ----------------------------------------------- |
| `DATABASE_URL`    | `postgresql://postgres:postgres@localhost:5432/…` | Prisma / Postgres for `User` table              |
| `DJANGO_BASE_URL` | `http://localhost:8000`                           | Upstream for all proxied routes                 |
| `PORT`            | `4000`                                            | HTTP listen port                                |
| `NODE_ENV`        | `development`                                     | Prisma log verbosity                            |
| `CORS_ORIGINS`    | *(empty)*                                         | Comma-separated; empty = permissive defaults    |
| `JWT_SECRET`      | —                                                 | **Required**, ≥ 16 chars; must match Django     |
| `JWT_EXPIRES_IN`  | `7d`                                              | Passed to `jsonwebtoken`                        |
| `BOOTSTRAP_ADMIN` | `true`                                            | First registrant → `ADMIN`                      |

---

## Quick start

```bash
cp .env.example .env          # fill DATABASE_URL, JWT_SECRET, DJANGO_BASE_URL
npm install
npx prisma generate
npx prisma migrate dev
npm run dev                   # http://localhost:4000
```

Ensure Django is running on `DJANGO_BASE_URL` before hitting proxied routes.

Smoke-test identity:

```bash
curl -s http://localhost:4000/health

curl -s -X POST http://localhost:4000/auth/register \
  -H 'content-type: application/json' \
  -d '{"email":"me@example.com","password":"hunter2hunter2","name":"Me"}'
```

---

## Project layout

Layered architecture — routes delegate to controllers, controllers to services,
services to repositories / datasources:

```
src/
  server.ts                 entry — listen, graceful shutdown + prisma.$disconnect
  app.ts                    Express factory — CORS, JSON, routes, 404, error handler

  routes/
    index.ts                mount order: auth → users → dashboard → proxy
    auth.ts
    users.ts
    dashboard.ts
    proxy.ts                http-proxy-middleware mounts

  controllers/              thin HTTP adapters (parse input, call service, res.json)
    auth.ts
    users.ts
    dashboard.ts

  services/                 business logic
    auth.ts
    users.ts
    dashboard.ts            BFF — aggregates Django via djangoClient

  repositories/             Prisma + Django data access
    user.ts
    builder.ts              listWorkflows (djangoClient)
    agentTools.ts           listTools (djangoClient)

  datasources/
    prisma.ts               shared PrismaClient singleton
    djangoClient.ts         server-side fetch to DJANGO_BASE_URL + JWT forward

  middleware/
    auth.ts                 requireAuth · requireAdmin
    requestLogger.ts        request ID + timing
    errorHandler.ts         relayErrorHandler

  validators/               Zod schemas
    auth.validator.ts
    users.validator.ts

  mappers/
    user.mapper.ts          publicUser projection (strips passwordHash)

  types/
    django.types.ts         minimal Django response shapes for BFF

  utils/
    errors.ts               HttpError · BadRequest · NotFound · Conflict
    http.ts                 asyncHandler
    jwt.ts                  signAccessToken · verifyAccessToken
    apiError.ts             normalizeUpstreamError · sendRelayError
    logger.ts               winston logger
    slugify.ts
    agentRegistry.ts        in-process tool catalog (library only, no HTTP route)

prisma/
  schema.prisma             User + legacy builder models (Django owns builder data)
  migrations/

tests/
  smoke.test.ts             identity end-to-end via supertest
```

---

## Scripts

| Command                   | What it does                                    |
| ------------------------- | ----------------------------------------------- |
| `npm run dev`             | `tsx watch src/server.ts`                       |
| `npm run build`           | `tsc` → `dist/`                                 |
| `npm start`               | `node dist/server.js`                           |
| `npm run prisma:generate` | Regenerate Prisma client                        |
| `npm run prisma:migrate`  | `prisma migrate dev`                            |
| `npm run prisma:reset`    | Wipe + reapply migrations                       |
| `npm run prisma:studio`   | Prisma Studio                                   |
| `npm run typecheck`       | `tsc --noEmit`                                  |
| `npm test`                | Node test runner + supertest smoke tests        |

---

## Persistence (Prisma)

Only the **`User`** table is read/written by this service today. The Prisma
schema still models the full builder domain (`Workflow`, `WorkArea`, `Workbench`,
`WorkflowRun`, …) for historical / shared-database reasons, but canvas state
lives in Django's Postgres schema, not via Node CRUD.

| Model            | Used by Node? | Notes                              |
| ---------------- | ------------- | ---------------------------------- |
| `User`           | Yes           | Identity + admin user management   |
| Builder models   | No            | Owned by Django `builder` app      |
| Run models       | No            | Owned by Django execution layer    |

---

## Relationship to Django & the frontend

| Service                    | Role                                              |
| -------------------------- | ------------------------------------------------- |
| **claims-corebackend**     | Identity, user admin, BFF, proxy (this repo)      |
| **uhc-agentic-backend**    | Workflow builder, catalog, SOP ingest, agents, runs |
| **uhc-claims-frontend**    | React SPA — single `VITE_API_BASE_URL` → Node     |

- `JWT_SECRET` must be **byte-for-byte identical** on Node and Django. Rotate both together.
- Tokens carry `sub`, `email`, `role`. Django authenticates proxied requests from the Bearer header.
- The frontend never sets a separate Django URL — all traffic goes through this relay.

---

## Tests

`tests/smoke.test.ts` exercises identity end-to-end against a live Postgres:

- `/auth/me` rejects unauthenticated requests
- Register → login → me → change-password flow
- `/workflows` (top-level, not proxied) returns **404**
- `/health` is public

Cleans up the test user in `after()`.

```bash
npm test
```
