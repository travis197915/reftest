/**
 * Smoke test for the trimmed corebackend.
 *
 * This service is now identity-only — register, login, /me, change-password.
 * Workflow builder state, the shape catalog, and server-driven UI metadata
 * all live in the Django `builder` app (sop_backend), which trusts the JWTs
 * we mint here via a shared `JWT_SECRET`.
 */
import { after, describe, it } from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import { createApp } from "../src/app.js";
import { prisma } from "../src/datasources/prisma.js";
import { signAccessToken } from "../src/utils/jwt.js";

const email = `smoke-${Date.now()}@toystack.dev`;
const password = "smoke-test-secret-1234";

const app = createApp();
let token = "";
let userId = "";
// RBAC middleware reads role from the JWT — no DB row required for these checks.
const auditorToken = signAccessToken({
  sub: "auditor-smoke-id",
  email: "auditor-smoke@toystack.dev",
  role: "AUDITOR",
});

describe("corebackend smoke", () => {
  after(async () => {
    await prisma.user.deleteMany({ where: { email } });
    await prisma.$disconnect();
  });

  describe("identity service", () => {
    it("rejects /auth/me without a token", async () => {
      const res = await request(app).get("/auth/me");
      assert.equal(res.status, 401);
    });

    it("registers a user and returns a JWT", async () => {
      const res = await request(app)
        .post("/auth/register")
        .send({ email, password, name: "Smoke Tester" });
      assert.equal(res.status, 201);
      assert.equal(typeof res.body.token, "string");
      assert.equal(res.body.user.email, email);
      token = res.body.token;
      userId = res.body.user.id;

      // Promote to ADMIN so write-operation smoke tests can run regardless of
      // whether this DB already had users at registration time.
      const admin = await prisma.user.update({
        where: { id: userId },
        data: { role: "ADMIN" },
      });
      token = signAccessToken({
        sub: admin.id,
        email: admin.email,
        role: admin.role,
      });
    });

    it("logs in with the same credentials", async () => {
      const res = await request(app).post("/auth/login").send({ email, password });
      assert.equal(res.status, 200);
      assert.equal(typeof res.body.token, "string");
    });

    it("returns the current user from /auth/me", async () => {
      const res = await request(app)
        .get("/auth/me")
        .set("Authorization", `Bearer ${token}`);
      assert.equal(res.status, 200);
      assert.equal(res.body.user.id, userId);
      assert.equal(res.body.user.email, email);
    });

    it("changes the password and the old one stops working", async () => {
      const newPassword = "new-smoke-test-secret-5678";
      const change = await request(app)
        .post("/auth/change-password")
        .set("Authorization", `Bearer ${token}`)
        .send({ currentPassword: password, newPassword });
      assert.equal(change.status, 200);

      const oldLogin = await request(app)
        .post("/auth/login")
        .send({ email, password });
      assert.equal(oldLogin.status, 401);

      const newLogin = await request(app)
        .post("/auth/login")
        .send({ email, password: newPassword });
      assert.equal(newLogin.status, 200);
    });

    it("workflow routes are gone — return 404", async () => {
      const res = await request(app)
        .get("/workflows")
        .set("Authorization", `Bearer ${token}`);
      assert.equal(res.status, 404);
    });

    it("/health is still public and reports components", async () => {
      const res = await request(app).get("/health");
      assert.equal(res.status, 200);
      assert.equal(res.body.status, "ok");
      assert.ok(typeof res.body.timestamp === "string");
      assert.equal(res.body.components.postgres.status, "ok");
    });
  });

  describe("role-based access", () => {
    it("blocks auditor write operations on proxied routes", async () => {
      const res = await request(app)
        .post("/api/builder/workflows/")
        .set("Authorization", `Bearer ${auditorToken}`)
        .send({ name: "blocked" });
      assert.equal(res.status, 403);
      assert.match(res.body.error, /admin role/i);
    });

    it("blocks auditor read access to builder catalog", async () => {
      const res = await request(app)
        .get("/api/builder/catalog/categories/")
        .set("Authorization", `Bearer ${auditorToken}`);
      assert.equal(res.status, 403);
      assert.match(res.body.error, /admin role/i);
    });

    it("allows auditor workflow list for audit-review-dashboard", async () => {
      const res = await request(app)
        .get("/api/builder/workflows/")
        .set("Authorization", `Bearer ${auditorToken}`);
      assert.notEqual(res.status, 403);
    });

    it("blocks auditor dashboard stats", async () => {
      const res = await request(app)
        .get("/api/dashboard/stats")
        .set("Authorization", `Bearer ${auditorToken}`);
      assert.equal(res.status, 403);
      assert.match(res.body.error, /admin role/i);
    });

    it("blocks auditor batch upload on execute routes", async () => {
      const res = await request(app)
        .post("/api/execute/workflows/wf-1/run-batch/")
        .set("Authorization", `Bearer ${auditorToken}`)
        .send({ file: "x" });
      assert.equal(res.status, 403);
      assert.match(res.body.error, /admin role/i);
    });

    it("allows auditor claim review-status updates", async () => {
      const res = await request(app)
        .patch("/api/claims/claim-1/review-status/")
        .set("Authorization", `Bearer ${auditorToken}`)
        .send({ reviewStatus: "in_progress" });
      assert.notEqual(res.status, 403);
    });

    it("allows auditor claim review approve", async () => {
      const res = await request(app)
        .post("/api/claims/claim-1/review/approve/")
        .set("Authorization", `Bearer ${auditorToken}`)
        .send({ feedback: "ok" });
      assert.notEqual(res.status, 403);
    });

    it("blocks auditor password changes", async () => {
      const res = await request(app)
        .post("/auth/change-password")
        .set("Authorization", `Bearer ${auditorToken}`)
        .send({ currentPassword: password, newPassword: "nope-12345678" });
      assert.equal(res.status, 403);
    });

    it("blocks auditor read access to user list", async () => {
      const res = await request(app)
        .get("/api/users/")
        .set("Authorization", `Bearer ${auditorToken}`);
      assert.equal(res.status, 403);
      assert.match(res.body.error, /admin role/i);
    });

    it("blocks auditor write access to user admin routes", async () => {
      const res = await request(app)
        .patch("/api/users/auditor-smoke-id/role")
        .set("Authorization", `Bearer ${auditorToken}`)
        .send({ role: "ADMIN" });
      assert.equal(res.status, 403);
    });
  });
});
