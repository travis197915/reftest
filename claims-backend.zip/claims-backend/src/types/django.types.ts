/** Minimal Django builder workflow list item. */
export interface DjangoWorkflow {
  id: string;
  name: string;
  is_active: boolean;
}

/** Minimal Django agent-tools registry item. */
export interface DjangoTool {
  id: string;
  name: string;
  is_active: boolean;
}

export interface DashboardStats {
  totalAgents: number;
  onlineAgents: number;
  activeWorkflows: number;
  totalTransactions: number;
}
