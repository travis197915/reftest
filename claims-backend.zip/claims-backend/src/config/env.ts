function required(name: string): string {
  const value = process.env[name];
  if (!value || !value.trim()) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

function toPort(raw: string): number {
  const port = Number(raw);
  if (!Number.isInteger(port) || port <= 0 || port > 65535) {
    throw new Error(`Invalid PORT value: ${raw}`);
  }
  return port;
}

function toBoolean(raw: string, name: string): boolean {
  const normalized = raw.trim().toLowerCase();
  if (normalized === "true") return true;
  if (normalized === "false") return false;
  throw new Error(`Invalid ${name} value: ${raw}. Use true or false.`);
}

export const env = {
  PORT: toPort(required("PORT")),
  DATABASE_URL: required("DATABASE_URL"),
  DJANGO_BASE_URL: required("DJANGO_BASE_URL").replace(/\/+$/, ""),
  JWT_SECRET: required("JWT_SECRET"),
  JWT_EXPIRES_IN: required("JWT_EXPIRES_IN"),
  BOOTSTRAP_ADMIN: toBoolean(required("BOOTSTRAP_ADMIN"), "BOOTSTRAP_ADMIN"),
  CORS_ORIGINS: process.env.CORS_ORIGINS ?? "",
  NODE_ENV: process.env.NODE_ENV,
} as const;