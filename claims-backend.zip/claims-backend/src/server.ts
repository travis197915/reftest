import { createApp } from "./app.js";
import { prisma } from "./datasources/prisma.js";
import { logger } from "./utils/logger.js";
import { env } from "./config/env.js";

const app = createApp();

const server = app.listen(env.PORT, () => {
  logger.info(`listening on http://localhost:${env.PORT}`);
});

async function shutdown(signal: NodeJS.Signals) {
  logger.info(`received ${signal} — shutting down`);
  server.close();
  await prisma.$disconnect();
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
