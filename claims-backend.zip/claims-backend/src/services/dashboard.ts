import { createDjangoClient } from "../datasources/djangoClient.js";
import { listTools } from "../repositories/agentTools.js";
import { listWorkflows } from "../repositories/builder.js";
import type {
  DashboardStats,
  DjangoTool,
  DjangoWorkflow,
} from "../types/django.types.js";

/** Aggregates dashboard counters from Django via djangoClient. */
export async function getDashboardStats(
  authHeader?: string,
): Promise<DashboardStats> {
  const client = createDjangoClient(authHeader);

  const [workflows, tools] = await Promise.all([
    listWorkflows(client).catch((): DjangoWorkflow[] => []),
    listTools(client).catch((): DjangoTool[] => []),
  ]);

  const activeTools = tools.filter((t) => t.is_active);

  return {
    totalAgents: tools.length,
    onlineAgents: activeTools.length,
    activeWorkflows: workflows.filter((w) => w.is_active).length,
    totalTransactions: 0,
  };
}
