import type { User } from "@prisma/client";
import bcrypt from "bcryptjs";
import { BadRequest, HttpError, NotFound } from "../utils/errors.js";
import { signAccessToken } from "../utils/jwt.js";
import { toPublicUser } from "../mappers/user.mapper.js";
import {
  countUsers,
  createUser,
  findUserByEmail,
  findUserById,
  updateUserPassword,
} from "../repositories/user.js";
import type {
  ChangePasswordInput,
  LoginInput,
  RegisterInput,
} from "../validators/auth.validator.js";
import { env } from "../config/env.js";

const BCRYPT_ROUNDS = 10;

async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

async function verifyPassword(
  password: string,
  passwordHash: string,
): Promise<boolean> {
  return bcrypt.compare(password, passwordHash);
}

function issueAuthResponse(user: User) {
  const token = signAccessToken({
    sub: user.id,
    email: user.email,
    role: user.role,
  });
  return { token, user: toPublicUser(user) };
}

export async function register(input: RegisterInput) {
  const existing = await findUserByEmail(input.email);
  if (existing) throw new BadRequest("Email already registered");

  const isFirst = (await countUsers()) === 0;
  const bootstrap = env.BOOTSTRAP_ADMIN;
  const role = isFirst && bootstrap ? "ADMIN" : "AUDITOR";

  const user = await createUser({
    email: input.email,
    passwordHash: await hashPassword(input.password),
    name: input.name ?? "",
    role,
  });

  return issueAuthResponse(user);
}

export async function login(input: LoginInput) {
  const user = await findUserByEmail(input.email);
  if (!user || !user.isActive) {
    throw new HttpError(401, "Invalid email or password");
  }

  const ok = await verifyPassword(input.password, user.passwordHash);
  if (!ok) throw new HttpError(401, "Invalid email or password");

  return issueAuthResponse(user);
}

export async function getMe(userId: string) {
  const user = await findUserById(userId);
  if (!user) throw new NotFound("User no longer exists");
  return { user: toPublicUser(user) };
}

export async function changePassword(
  userId: string,
  input: ChangePasswordInput,
) {
  const user = await findUserById(userId);
  if (!user) throw new NotFound("User no longer exists");

  const ok = await verifyPassword(input.currentPassword, user.passwordHash);
  if (!ok) throw new HttpError(401, "Current password is incorrect");

  await updateUserPassword(user.id, await hashPassword(input.newPassword));

  return { ok: true as const };
}
