import type { Prisma } from "@prisma/client";
import { NotFound } from "../utils/errors.js";
import { toPublicUser } from "../mappers/user.mapper.js";
import {
  countUsersWhere,
  findManyUsersPaginated,
  findUserById,
  updateUserRole,
  updateUserStatus,
} from "../repositories/user.js";
import type {
  ListUsersQuery,
  RoleInput,
  StatusInput,
} from "../validators/users.validator.js";

function buildSearchWhere(search?: string): Prisma.UserWhereInput {
  if (!search) return {};
  return {
    OR: [
      { email: { contains: search, mode: "insensitive" } },
      { name: { contains: search, mode: "insensitive" } },
    ],
  };
}

export async function listUsers(query: ListUsersQuery) {
  const where = buildSearchWhere(query.search);
  const users = await findManyUsersPaginated({
    where,
    limit: query.limit,
    cursor: query.cursor,
  });

  const hasNextPage = users.length > query.limit;
  const page = hasNextPage ? users.slice(0, query.limit) : users;

  return {
    nodes: page.map(toPublicUser),
    pageInfo: {
      hasNextPage,
      cursor: hasNextPage ? page[page.length - 1]!.id : null,
      totalCount: await countUsersWhere(where),
    },
  };
}

export async function getUserById(id: string) {
  const user = await findUserById(id);
  if (!user) throw new NotFound("User not found");
  return toPublicUser(user);
}

export async function updateUserRoleById(id: string, input: RoleInput) {
  const user = await findUserById(id);
  if (!user) throw new NotFound("User not found");

  const updated = await updateUserRole(id, input.role);
  return toPublicUser(updated);
}

export async function updateUserStatusById(id: string, input: StatusInput) {
  const user = await findUserById(id);
  if (!user) throw new NotFound("User not found");

  const updated = await updateUserStatus(id, input.isActive);
  return toPublicUser(updated);
}
