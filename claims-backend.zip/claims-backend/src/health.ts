import type { Request, Response } from "express";
import { prisma } from "./datasources/prisma.js";
import { env } from "./config/env.js";

type ComponentOk = {
  status: "ok";
  detail: string;
  latency_ms: number;
};

type ComponentFail = {
  status: "fail";
  error: string;
  latency_ms: number;
};

type ComponentResult = ComponentOk | ComponentFail;

// scheme://[creds@]host[:port][/rest] — captures scheme + trailing path/db.
const URI_RE =
  /^(?<scheme>[\w+]+:\/\/)(?:[^@/]+@)?[^/]+(?<rest>\/.*)?$/;

/** Hide host/port (and credentials) in a connection string for public responses. */
function mask(uri: string): string {
  const m = URI_RE.exec(uri);
  if (!m?.groups) return "***";
  return `${m.groups.scheme}***${m.groups.rest ?? ""}`;
}

async function timed(check: () => Promise<string>): Promise<ComponentResult> {
  const t0 = performance.now();
  try {
    const detail = await check();
    return {
      status: "ok",
      detail,
      latency_ms: Math.round((performance.now() - t0) * 10) / 10,
    };
  } catch (err) {
    const message =
      err instanceof Error
        ? `${err.constructor.name}: ${err.message}`
        : String(err);
    return {
      status: "fail",
      error: message,
      latency_ms: Math.round((performance.now() - t0) * 10) / 10,
    };
  }
}

async function checkPostgres(): Promise<string> {
  await prisma.$queryRaw`SELECT 1`;
  const dbUrl = env.DATABASE_URL;
  return mask(dbUrl);
}

export async function healthHandler(
  _req: Request,
  res: Response,
): Promise<void> {
  const components: Record<string, ComponentResult> = {
    postgres: await timed(checkPostgres),
  };

  const allOk = Object.values(components).every((c) => c.status === "ok");
  res.status(allOk ? 200 : 503).json({
    status: allOk ? "ok" : "degraded",
    timestamp: new Date().toISOString(),
    components,
  });
}
