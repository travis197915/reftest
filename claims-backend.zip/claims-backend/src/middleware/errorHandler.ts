import type { ErrorRequestHandler } from "express";
import { ZodError } from "zod";
import { Prisma } from "@prisma/client";
import { HttpError } from "../utils/errors.js";
import { logger } from "../utils/logger.js";
import { sendRelayError } from "../utils/apiError.js";

/** Handles errors thrown in the Node relay (auth, users, Prisma). */
export const relayErrorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  if (err instanceof HttpError) {
    sendRelayError(res, err.status, err.message, err.details);
    return;
  }

  if (err instanceof ZodError) {
    sendRelayError(res, 400, "Validation failed", err.flatten());
    return;
  }

  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    const status =
      err.code === "P2025" ? 404 : err.code === "P2002" ? 409 : 400;
    sendRelayError(res, status, err.message, err.meta, err.code);
    return;
  }

  if (err instanceof SyntaxError && "body" in err) {
    sendRelayError(res, 400, "Invalid JSON in request body");
    return;
  }

  logger.error("[unhandled]", {
    requestId: req.requestId,
    operationName: `${req.method} ${req.originalUrl}`,
    message: err instanceof Error ? err.message : String(err),
    stack: err instanceof Error ? err.stack : undefined,
  });
  sendRelayError(res, 500, "Internal server error");
};
