import type { NextFunction, Request, Response } from "express";
import { randomUUID } from "node:crypto";
import { logger } from "../utils/logger.js";

declare module "express-serve-static-core" {
  interface Request {
    requestId?: string;
  }
}

export function requestLogger(req: Request, res: Response, next: NextFunction) {
  const requestId = randomUUID();
  req.requestId = requestId;

  const operationName = `${req.method} ${req.originalUrl}`;
  const start = Date.now();

  if (req.originalUrl !== "/health") {
    logger.info("Request started", { requestId, operationName });
  }

  res.on("finish", () => {
    if (req.originalUrl === "/health") return;

    const durationMs = Date.now() - start;
    const message = `Sending response ${res.statusCode} ${durationMs}ms`;
    const meta = { requestId, operationName };

    if (res.statusCode >= 500) {
      logger.error(message, meta);
    } else if (res.statusCode >= 400) {
      logger.warn(message, meta);
    } else {
      logger.info(message, meta);
    }
  });

  next();
}
