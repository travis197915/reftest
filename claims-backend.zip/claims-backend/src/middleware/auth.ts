import type { NextFunction, Request, Response } from "express";
import { verifyAccessToken, type JwtClaims } from "../utils/jwt.js";
import { HttpError } from "../utils/errors.js";

declare module "express-serve-static-core" {
  interface Request {
    /** Populated by `requireAuth`; absent on public routes. */
    auth?: JwtClaims;
  }
}

/**
 * Extracts and verifies a Bearer JWT.  Rejects with 401 when missing /
 * invalid / expired.  On success the decoded claims are stashed on
 * `req.auth` so downstream handlers can do role checks.
 */
export function requireAuth(req: Request, _res: Response, next: NextFunction): void {
  const header = req.headers.authorization ?? "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) {
    return next(new HttpError(401, "Missing or malformed Authorization header"));
  }
  try {
    req.auth = verifyAccessToken(token);
    next();
  } catch (err) {
    next(new HttpError(401, err instanceof Error ? err.message : "Invalid token"));
  }
}

const READ_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

/**
 * Blocks write operations for AUDITOR role.  Must come *after* `requireAuth`.
 * GET / HEAD / OPTIONS pass through; POST / PUT / PATCH / DELETE require ADMIN.
 */
export function requireWriteAccess(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  if (READ_METHODS.has(req.method.toUpperCase())) {
    return next();
  }
  if (req.auth?.role === "ADMIN") {
    return next();
  }
  return next(new HttpError(403, "Write access requires admin role"));
}

/** Auditors may update run review workflow status on the audit-review app. */
const EXECUTE_AUDITOR_WRITE_PATH = /^\/runs\/[^/]+\/review-status\/?$/;

/**
 * Execution proxy access.  ADMIN has full access.  AUDITOR may read everything
 * and PATCH run review-status; batch uploads remain admin-only.
 */
export function requireExecuteAccess(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  if (READ_METHODS.has(req.method.toUpperCase())) {
    return next();
  }
  if (req.auth?.role === "ADMIN") {
    return next();
  }
  const method = req.method.toUpperCase();
  if (method === "PATCH" && EXECUTE_AUDITOR_WRITE_PATH.test(req.path)) {
    return next();
  }
  return next(new HttpError(403, "Write access requires admin role"));
}

function isClaimsAuditorWrite(method: string, path: string): boolean {
  if (method === "PATCH" && /^\/[^/]+\/review-status\/?$/.test(path)) {
    return true;
  }
  if (
    method === "POST"
    && /^\/[^/]+\/review\/(approve|reject)\/?$/.test(path)
  ) {
    return true;
  }
  return false;
}

/**
 * Claims proxy access.  ADMIN has full access.  AUDITOR may read everything
 * and submit review workflow updates / approve / reject outcomes.
 */
export function requireClaimsAccess(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  if (READ_METHODS.has(req.method.toUpperCase())) {
    return next();
  }
  if (req.auth?.role === "ADMIN") {
    return next();
  }
  if (isClaimsAuditorWrite(req.method.toUpperCase(), req.path)) {
    return next();
  }
  return next(new HttpError(403, "Write access requires admin role"));
}

/** Restrict to ADMIN role.  Must come *after* `requireAuth`. */
export function requireAdmin(req: Request, _res: Response, next: NextFunction): void {
  if (req.auth?.role !== "ADMIN") {
    return next(new HttpError(403, "Admin role required"));
  }
  next();
}

/** Workflow list only — audit-review-dashboard auditors may list workflows. */
const BUILDER_AUDITOR_LIST_PATH = /^\/workflows\/?$/;

/**
 * Builder proxy access.  ADMIN has full access.  AUDITOR may only
 * `GET /workflows/` (workflow picker on the audit-review app).
 */
export function requireBuilderAccess(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  if (req.auth?.role === "ADMIN") {
    return next();
  }
  const method = req.method.toUpperCase();
  if (method === "GET" && BUILDER_AUDITOR_LIST_PATH.test(req.path)) {
    return next();
  }
  return next(new HttpError(403, "Admin role required"));
}
