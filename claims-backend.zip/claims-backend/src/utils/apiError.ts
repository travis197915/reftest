import type { Response } from "express";

/** JSON error envelope returned to the frontend for all relay + Django failures. */
export interface ApiErrorResponse {
  error: string;
  details?: unknown;
  code?: string;
  source: "relay" | "django";
}

export function httpStatusLabel(status: number): string {
  const labels: Record<number, string> = {
    400: "Bad request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not found",
    409: "Conflict",
    422: "Validation failed",
    500: "Internal server error",
    502: "Upstream service unavailable",
    503: "Service unavailable",
  };
  return labels[status] ?? `Request failed (${status})`;
}

function summarizeFieldErrors(obj: Record<string, unknown>): string | undefined {
  const parts: string[] = [];
  for (const [key, value] of Object.entries(obj)) {
    if (key === "detail") continue;
    if (Array.isArray(value)) {
      parts.push(`${key}: ${value.map(String).join(", ")}`);
    } else if (typeof value === "string") {
      parts.push(`${key}: ${value}`);
    } else if (value && typeof value === "object") {
      parts.push(`${key}: ${JSON.stringify(value)}`);
    }
  }
  return parts.length > 0 ? parts.join("; ") : undefined;
}

/**
 * Normalize Django / DRF error payloads into the relay JSON envelope.
 * Handles `{ detail }`, field validation objects, HTML debug pages, and plain text.
 */
export function normalizeUpstreamError(
  statusCode: number,
  raw: unknown,
): ApiErrorResponse {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    const obj = raw as Record<string, unknown>;

    if (typeof obj.error === "string" && obj.source === "relay") {
      return {
        error: obj.error,
        details: obj.details,
        code: typeof obj.code === "string" ? obj.code : undefined,
        source: "relay",
      };
    }

    if (typeof obj.error === "string") {
      return {
        error: obj.error,
        details: obj.details ?? undefined,
        code: typeof obj.code === "string" ? obj.code : undefined,
        source: "django",
      };
    }

    if ("detail" in obj) {
      const detail = obj.detail;
      if (typeof detail === "string") {
        return { error: detail, source: "django" };
      }
      if (Array.isArray(detail)) {
        return {
          error: detail.map(String).join("; "),
          details: obj,
          source: "django",
        };
      }
      if (detail && typeof detail === "object") {
        const nested = summarizeFieldErrors(detail as Record<string, unknown>);
        return {
          error: nested ?? httpStatusLabel(statusCode),
          details: detail,
          source: "django",
        };
      }
    }

    const summary = summarizeFieldErrors(obj);
    if (summary) {
      return { error: summary, details: obj, source: "django" };
    }
  }

  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (trimmed.startsWith("<")) {
      return { error: httpStatusLabel(statusCode), source: "django" };
    }
    if (trimmed) {
      return { error: trimmed.slice(0, 500), source: "django" };
    }
  }

  return { error: httpStatusLabel(statusCode), source: "django" };
}

export function sendRelayError(
  res: Response,
  status: number,
  error: string,
  details?: unknown,
  code?: string,
): void {
  const body: ApiErrorResponse = {
    error,
    details,
    code,
    source: "relay",
  };
  res.status(status).json(body);
}
