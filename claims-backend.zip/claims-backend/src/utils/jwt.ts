import jwt, { type SignOptions } from "jsonwebtoken";
import { env } from "../config/env.js";

/** Subject embedded in every issued JWT. */
export interface JwtClaims {
  sub: string; // user id
  email: string;
  role: "ADMIN" | "AUDITOR";
}

function secret(): string {
  const value = env.JWT_SECRET;
  if (!value || value.length < 16) {
    throw new Error("JWT_SECRET env var missing or too short (need ≥ 16 chars).");
  }
  return value;
}

export function signAccessToken(claims: JwtClaims): string {
  const expiresIn = env.JWT_EXPIRES_IN as SignOptions["expiresIn"];
  return jwt.sign(claims, secret(), { expiresIn });
}

export function verifyAccessToken(token: string): JwtClaims {
  const decoded = jwt.verify(token, secret());
  if (typeof decoded === "string" || !decoded.sub) {
    throw new Error("Malformed access token");
  }
  return decoded as JwtClaims;
}
