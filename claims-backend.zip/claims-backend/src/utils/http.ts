import type { NextFunction, Request, Response } from "express";

/**
 * Wrap an async route handler so thrown errors propagate to Express'
 * `next(err)` chain (and therefore to the central error handler).
 */
export function asyncHandler<TReq extends Request = Request>(
  handler: (req: TReq, res: Response, next: NextFunction) => Promise<unknown>,
) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(handler(req as TReq, res, next)).catch(next);
  };
}
