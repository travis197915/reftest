import dayjs from 'dayjs';
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
});

const logFormat = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp(),
  winston.format.align(),
  winston.format.printf(
    info =>
      `${info.level} | ${dayjs(info.timestamp as string).toLocaleString()} | ${info.requestId || 'N/A - Request Id'} | ${
        info.operationName || 'N/A - Operation Name'
      } | ${info.message}`
  )
);

logger.add(
  new winston.transports.Console({
    format: logFormat,
  })
);

export { logger };
