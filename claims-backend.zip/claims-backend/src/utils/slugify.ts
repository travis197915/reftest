/**
 * Lightweight slugifier — lowercases, strips diacritics, collapses
 * non-alphanumeric runs to single dashes.  No external dependency.
 */
export function slugify(input: string): string {
  return input
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
