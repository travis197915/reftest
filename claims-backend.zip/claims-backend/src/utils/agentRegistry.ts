/**
 * Lightweight in-process registry of available agents / tools.  The builder
 * UI fetches `GET /agent-types/` to populate the "Action" dropdown when the
 * user attaches a tool to a Workbench.  Add new entries here as you build
 * runtime handlers.
 */

export interface AgentTypeDescriptor {
  name: string;
  label: string;
  description?: string;
  /** JSON-schema-ish hint for the inspector to render a config form. */
  configSchema?: Record<string, unknown>;
}

const REGISTRY = new Map<string, AgentTypeDescriptor>();

export function registerAgentType(descriptor: AgentTypeDescriptor): void {
  REGISTRY.set(descriptor.name, descriptor);
}

export function listAgentTypes(): AgentTypeDescriptor[] {
  return [...REGISTRY.values()].sort((a, b) => a.name.localeCompare(b.name));
}

// ── Built-ins — mirror the previous Django claims-engine agents ──────────────
registerAgentType({
  name: "eligibility",
  label: "Eligibility Lookup",
  description: "Validates a member ID and returns the member record.",
  configSchema: {},
});
registerAgentType({
  name: "benefits",
  label: "Benefits Fetch",
  description: "Looks up plan coverage & benefit limits for the member.",
  configSchema: {},
});
registerAgentType({
  name: "llm_summary",
  label: "LLM Summary",
  description: "Summarises eligibility + benefits into a human response.",
  configSchema: { model: "string", prompt: "string" },
});
registerAgentType({
  name: "http_request",
  label: "HTTP Request",
  description: "Generic HTTP call (method, url, headers, body).",
  configSchema: { method: "string", url: "string" },
});
