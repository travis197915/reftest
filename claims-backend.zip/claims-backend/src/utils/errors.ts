export class HttpError extends Error {
  status: number;
  details?: unknown;
  constructor(status: number, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export class BadRequest extends HttpError {
  constructor(message = "Bad request", details?: unknown) {
    super(400, message, details);
  }
}

export class NotFound extends HttpError {
  constructor(message = "Not found") {
    super(404, message);
  }
}

export class Conflict extends HttpError {
  constructor(message = "Conflict", details?: unknown) {
    super(409, message, details);
  }
}
