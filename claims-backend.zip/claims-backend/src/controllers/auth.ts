import type { Request, Response } from "express";
import { asyncHandler } from "../utils/http.js";
import {
  changePassword as changePasswordForUser,
  getMe as getCurrentUser,
  login as loginUser,
  register as registerUser,
} from "../services/auth.js";
import {
  ChangePasswordInput,
  LoginInput,
  RegisterInput,
} from "../validators/auth.validator.js";

export const register = asyncHandler(async (req: Request, res: Response) => {
  const input = RegisterInput.parse(req.body);
  const result = await registerUser(input);
  res.status(201).json(result);
});

export const login = asyncHandler(async (req: Request, res: Response) => {
  const input = LoginInput.parse(req.body);
  const result = await loginUser(input);
  res.json(result);
});

export const me = asyncHandler(async (req: Request, res: Response) => {
  const result = await getCurrentUser(req.auth!.sub);
  res.json(result);
});

export const changePassword = asyncHandler(
  async (req: Request, res: Response) => {
    const input = ChangePasswordInput.parse(req.body);
    const result = await changePasswordForUser(req.auth!.sub, input);
    res.json(result);
  },
);
