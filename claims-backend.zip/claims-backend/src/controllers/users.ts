import type { Request, Response } from "express";
import { asyncHandler } from "../utils/http.js";
import {
  getUserById,
  listUsers,
  updateUserRoleById,
  updateUserStatusById,
} from "../services/users.js";
import {
  ListUsersQuery,
  RoleInput,
  StatusInput,
} from "../validators/users.validator.js";

export const GetUsers = asyncHandler(async (req: Request, res: Response) => {
  const query = ListUsersQuery.parse(req.query);
  const result = await listUsers(query);
  res.json(result);
});

export const GetUserById = asyncHandler(async (req: Request, res: Response) => {
  const user = await getUserById(req.params.id);
  res.json(user);
});

export const UpdateUserRole = asyncHandler(async (req: Request, res: Response) => {
  const input = RoleInput.parse(req.body);
  const user = await updateUserRoleById(req.params.id, input);
  res.json(user);
});

export const UpdateUserStatus = asyncHandler(async (req: Request, res: Response) => {
  const input = StatusInput.parse(req.body);
  const user = await updateUserStatusById(req.params.id, input);
  res.json(user);
});
