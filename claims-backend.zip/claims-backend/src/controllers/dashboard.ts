import type { Request, Response } from "express";
import { asyncHandler } from "../utils/http.js";
import { getDashboardStats } from "../services/dashboard.js";

export const stats = asyncHandler(async (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const result = await getDashboardStats(
    typeof authHeader === "string" ? authHeader : undefined,
  );
  res.json(result);
});
