import type { DjangoClient } from "../datasources/djangoClient.js";
import type { DjangoWorkflow } from "../types/django.types.js";

export function listWorkflows(client: DjangoClient): Promise<DjangoWorkflow[]> {
  return client.get<DjangoWorkflow[]>("/api/builder/workflows/");
}
