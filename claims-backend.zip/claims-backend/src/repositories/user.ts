import type { Prisma, User, UserRole } from "@prisma/client";
import { getPrismaInstance } from "../datasources/prisma.js";

const prisma = getPrismaInstance();

export function countUsers(): Promise<number> {
  return prisma.user.count();
}

export function countUsersWhere(where: Prisma.UserWhereInput): Promise<number> {
  return prisma.user.count({ where });
}

export function findUserByEmail(email: string): Promise<User | null> {
  return prisma.user.findUnique({ where: { email } });
}

export function findUserById(id: string): Promise<User | null> {
  return prisma.user.findUnique({ where: { id } });
}

export function createUser(data: Prisma.UserCreateInput): Promise<User> {
  return prisma.user.create({ data });
}

export function updateUserPassword(
  id: string,
  passwordHash: string,
): Promise<User> {
  return prisma.user.update({ where: { id }, data: { passwordHash } });
}

export function updateUserRole(id: string, role: UserRole): Promise<User> {
  return prisma.user.update({ where: { id }, data: { role } });
}

export function updateUserStatus(id: string, isActive: boolean): Promise<User> {
  return prisma.user.update({ where: { id }, data: { isActive } });
}

export function findManyUsersPaginated(params: {
  where: Prisma.UserWhereInput;
  limit: number;
  cursor?: string;
}): Promise<User[]> {
  const { where, limit, cursor } = params;
  return prisma.user.findMany({
    where,
    take: limit + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    orderBy: { createdAt: "desc" },
  });
}
