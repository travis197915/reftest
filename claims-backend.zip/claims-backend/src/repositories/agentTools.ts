import type { DjangoClient } from "../datasources/djangoClient.js";
import type { DjangoTool } from "../types/django.types.js";

export function listTools(client: DjangoClient): Promise<DjangoTool[]> {
  return client.get<DjangoTool[]>("/api/agent-tools/");
}
