import {
  createProxyMiddleware,
  fixRequestBody,
  responseInterceptor,
  type Options,
} from "http-proxy-middleware";
import type { Application, Request, RequestHandler } from "express";
import { requireAuth, requireWriteAccess, requireAdmin, requireBuilderAccess, requireExecuteAccess, requireClaimsAccess } from "../middleware/auth.js";
import { logger } from "../utils/logger.js";
import { normalizeUpstreamError, sendRelayError } from "../utils/apiError.js";
import { env } from "../config/env.js";

const DJANGO_BASE = env.DJANGO_BASE_URL;

/**
 * Execution + claims routes proxied to Django `execution_app`.
 * See `docs/Execution APIs.md` for request/response contracts.
 */
export const EXECUTION_PROXY_ROUTES = [
  "POST /api/execute/workflows/:workflowId/run-batch/",
  "POST /api/execute/workflows/:workflowId/run-batch-async/",
  "GET  /api/execute/batches/latest/",
  "GET  /api/execute/batches/:batchId/",
  "GET  /api/execute/batches/:batchId/events/", // streaming proxy (SSE)
  "GET  /api/execute/runs/",
  "GET  /api/execute/runs/:runId/",
  "GET  /api/execute/runs/:runId/nodes/",
  "PATCH /api/execute/runs/:runId/review-status/",
  "GET  /api/claims/:claimId/processing/",
  "PATCH /api/claims/:claimId/review-status/",
  "POST /api/claims/:claimId/review/approve/",
  "POST /api/claims/:claimId/review/reject/",
] as const;

/**
 * SOP document versioning + revision-check routes proxied to Django ingest app.
 * See `docs/Ingest APIs.md` for request/response contracts.
 */
export const INGEST_PROXY_ROUTES = [
  "GET  /api/ingest/documents/:documentId/versions/",
  "GET  /api/ingest/documents/:documentId/affected-workflows/",
  "POST /api/ingest/documents/:documentId/revision-check/",
  "POST /api/ingest/revision-check/",
  "GET  /api/ingest/sops/:sopId/diff/",
  "POST /api/ingest/sops/:sopId/activate/",
  "POST /api/ingest/sops/:sopId/reject/",
  "GET  /api/ingest/:jobId/",
] as const;

/** SSE batch progress — must not buffer the response body. */
function isExecuteEventsPath(req: Request): boolean {
  return /\/events\/?$/.test(req.path);
}

function sharedProxyOn(prefix: string): Options["on"] {
  return {
    proxyReq: (proxyReq, req: any) => {
      const upstreamPath = `${prefix}${req.url ?? ""}`;
      logger.debug(`proxy → ${DJANGO_BASE}${upstreamPath}`);
      const auth = req.headers["authorization"];
      if (auth) proxyReq.setHeader("authorization", auth);
      // Never rewrite multipart bodies — fixRequestBody only supports plain
      // string fields and will drop binary file parts (→ Django 400
      // "file (multipart) is required"). Stream the original request instead.
      const contentType = String(req.headers["content-type"] ?? "");
      if (!contentType.includes("multipart/form-data")) {
        fixRequestBody(proxyReq, req);
      }
    },
    error: (err, req, res: any) => {
      logger.error(`proxy upstream error ${req.method} ${req.url}: ${err.message}`);
      if (!res.headersSent) {
        sendRelayError(res, 502, "Upstream service unavailable");
      }
    },
  };
}

function makeProxy(mountPath: string): RequestHandler {
  // Express strips the mount path before the proxy sees req.url, so re-prefix
  // so Django receives the full path (e.g. /api/builder/ui/navigation/).
  const prefix = mountPath.replace(/\/+$/, "");

  return createProxyMiddleware({
    target: DJANGO_BASE,
    changeOrigin: true,
    selfHandleResponse: true,
    pathRewrite: (path) => `${prefix}${path}`,
    on: {
      ...sharedProxyOn(prefix),
      proxyRes: responseInterceptor(
        async (responseBuffer, proxyRes, req, res) => {
          const status = proxyRes.statusCode ?? 500;
          if (status < 400) {
            return responseBuffer;
          }

          const contentType = String(proxyRes.headers["content-type"] ?? "");
          const rawText = responseBuffer.toString("utf8");
          let parsed: unknown = rawText;

          if (contentType.includes("application/json")) {
            try {
              parsed = JSON.parse(rawText);
            } catch {
              parsed = rawText;
            }
          }

          const body = normalizeUpstreamError(status, parsed);
          res.setHeader("content-type", "application/json; charset=utf-8");

          logger.warn("Django error response", {
            requestId: (req as { requestId?: string }).requestId,
            operationName: `${req.method} ${(req as Request).originalUrl ?? req.url ?? ""}`,
            message: body.error,
            status,
          });

          return Buffer.from(JSON.stringify(body), "utf8");
        },
      ),
    },
  }) as RequestHandler;
}

/** Pipes responses without buffering — required for SSE event streams. */
function makeStreamingProxy(mountPath: string): RequestHandler {
  const prefix = mountPath.replace(/\/+$/, "");

  return createProxyMiddleware({
    target: DJANGO_BASE,
    changeOrigin: true,
    pathRewrite: (path) => `${prefix}${path}`,
    on: sharedProxyOn(prefix),
  }) as RequestHandler;
}

const adminProxyChain = [requireAuth, requireAdmin] as const;
const builderProxyChain = [requireAuth, requireBuilderAccess] as const;
const executeProxyChain = [requireAuth, requireExecuteAccess] as const;
const claimsProxyChain = [requireAuth, requireClaimsAccess] as const;

export function mountProxies(app: Application): void {
  const executeJsonProxy = makeProxy("/api/execute");
  const executeStreamProxy = makeStreamingProxy("/api/execute");

  // Builder — catalog, UI chrome, workflows (/api/builder/workflows/), workbenches, shapes
  app.use("/api/builder", ...builderProxyChain, makeProxy("/api/builder"));
  // Ingestion — jobs, SOP graph/sections, versioning (see INGEST_PROXY_ROUTES)
  app.use("/api/ingest", ...adminProxyChain, makeProxy("/api/ingest"));
  app.use("/api/agent-tools", ...adminProxyChain, makeProxy("/api/agent-tools"));
  app.use("/api/agents", ...adminProxyChain, makeProxy("/api/agents"));
  app.use("/api/combo-templates", ...adminProxyChain, makeProxy("/api/combo-templates"));

  // execution_app — batch runs, SSE, run audit (see EXECUTION_PROXY_ROUTES)
  app.use(
    "/api/execute",
    ...executeProxyChain,
    (req, res, next) => {
      if (isExecuteEventsPath(req)) {
        return executeStreamProxy(req, res, next);
      }
      return executeJsonProxy(req, res, next);
    },
  );
  // execution_app — claim processing + review-status (see EXECUTION_PROXY_ROUTES)
  app.use("/api/claims", ...claimsProxyChain, makeProxy("/api/claims"));
}
