import { Router } from "express";
import * as authController from "../controllers/auth.js";
import { requireAuth, requireWriteAccess } from "../middleware/auth.js";

const router = Router();

router.post("/register", authController.register);
router.post("/login", authController.login);
router.get("/me", requireAuth, authController.me);
router.post(
  "/change-password",
  requireAuth,
  requireWriteAccess,
  authController.changePassword,
);

export default router;
