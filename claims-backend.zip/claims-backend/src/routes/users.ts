import { Router } from "express";
import {
  GetUsers,
  GetUserById,
  UpdateUserRole,
  UpdateUserStatus,
} from "../controllers/users.js";
import { requireAuth, requireAdmin } from "../middleware/auth.js";

const router = Router();

router.get("/", requireAuth, requireAdmin, GetUsers);
router.get("/:id", requireAuth, requireAdmin, GetUserById);
router.patch("/:id/role", requireAuth, requireAdmin, UpdateUserRole);
router.patch("/:id/status", requireAuth, requireAdmin, UpdateUserStatus);

export default router;
