import type { Application } from "express";
import auth from "./auth.js";
import users from "./users.js";
import dashboard from "./dashboard.js";
import { mountProxies } from "./proxy.js";
import { healthHandler } from "../health.js";

/** Mount all HTTP routes — Node-owned handlers first, Django proxy last. */
export function registerRoutes(app: Application): void {
  // Public dependency probe (postgres) — same shape as agentic /api/health/
  app.get("/health", healthHandler);

  // ── Identity (Prisma + JWT minting) ───────────────────────────────────────
  app.use("/auth", auth);

  // ── User management (Prisma) ──────────────────────────────────────────────
  app.use("/api/users", users);

  // ── BFF / orchestration (Node → Django via djangoClient) ─────────────────
  app.use("/api/dashboard", dashboard);

  // ── Pass-through proxy → Django agentic-backend ───────────────────────────
  mountProxies(app);
}
