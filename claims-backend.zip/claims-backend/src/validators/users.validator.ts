import { z } from "zod";

export const RoleInput = z.object({ role: z.enum(["ADMIN", "AUDITOR"]) });
export const StatusInput = z.object({ isActive: z.boolean() });

export const ListUsersQuery = z.object({
  limit: z.coerce.number().int().min(1).max(200).default(50),
  cursor: z.string().optional(),
  search: z.string().optional(),
});

export type RoleInput = z.infer<typeof RoleInput>;
export type StatusInput = z.infer<typeof StatusInput>;
export type ListUsersQuery = z.infer<typeof ListUsersQuery>;
