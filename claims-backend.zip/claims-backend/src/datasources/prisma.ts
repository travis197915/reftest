import { PrismaClient } from "@prisma/client";
import { env } from "../config/env.js";

let client: PrismaClient | null = null;

export function getPrismaInstance(): PrismaClient {
  if (!client) {
    client = new PrismaClient({
      log:
        env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
    });
  }
  return client;
}

/** Shared singleton — prefer in repositories via getPrismaInstance(). */
export const prisma = getPrismaInstance();
