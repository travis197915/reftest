import type { Request } from "express";
import { HttpError } from "../utils/errors.js";
import { normalizeUpstreamError } from "../utils/apiError.js";
import { env } from "../config/env.js";

const DJANGO_BASE = env.DJANGO_BASE_URL;

export class DjangoHttpError extends HttpError {
  readonly source = "django" as const;

  constructor(status: number, message: string, details?: unknown) {
    super(status, message, details);
  }
}

export interface DjangoClient {
  get<T>(path: string): Promise<T>;
  post<T>(path: string, body?: unknown): Promise<T>;
  put<T>(path: string, body?: unknown): Promise<T>;
  patch<T>(path: string, body?: unknown): Promise<T>;
  delete<T>(path: string): Promise<T>;
}

async function parseBody(res: globalThis.Response): Promise<unknown> {
  const text = await res.text();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function buildClient(authHeader?: string): DjangoClient {
  async function request<T>(
    method: string,
    path: string,
    body?: unknown,
  ): Promise<T> {
    const url = `${DJANGO_BASE}${path.startsWith("/") ? path : `/${path}`}`;
    const headers: Record<string, string> = { Accept: "application/json" };

    if (authHeader) headers.Authorization = authHeader;
    if (body !== undefined) headers["Content-Type"] = "application/json";

    const res = await fetch(url, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });

    const payload = await parseBody(res);

    if (!res.ok) {
      const normalized = normalizeUpstreamError(res.status, payload);
      throw new DjangoHttpError(
        res.status,
        normalized.error,
        normalized.details,
      );
    }

    return payload as T;
  }

  return {
    get: (path) => request("GET", path),
    post: (path, body) => request("POST", path, body),
    put: (path, body) => request("PUT", path, body),
    patch: (path, body) => request("PATCH", path, body),
    delete: (path) => request("DELETE", path),
  };
}

/** Create a Django HTTP client that forwards the caller's JWT. */
export function createDjangoClient(authHeader?: string): DjangoClient {
  return buildClient(authHeader);
}

/** Convenience helper for controllers — reads Authorization from the request. */
export function djangoClientFromRequest(req: Pick<Request, "headers">): DjangoClient {
  const auth = req.headers.authorization;
  return createDjangoClient(typeof auth === "string" ? auth : undefined);
}
