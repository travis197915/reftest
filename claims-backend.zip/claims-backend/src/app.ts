import express, { type Request, type Response } from "express";
import cors from "cors";
import { registerRoutes } from "./routes/index.js";
import { requestLogger } from "./middleware/requestLogger.js";
import { relayErrorHandler } from "./middleware/errorHandler.js";
import { env } from "./config/env.js";

export function createApp() {
  const app = express();

  const origins = env.CORS_ORIGINS
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  // Dev frontends bounce between Vite ports (5173 → 5174 → 5175 …), so allow
  // any localhost/127.0.0.1 origin in addition to the explicitly-configured
  // production origins. Methods are pinned (incl. PATCH/OPTIONS) so preflight
  // never rejects a valid mutating request.
  const localhostOrigin = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;
  app.use(
    cors({
      origin(origin, cb) {
        // Non-browser / same-origin requests send no Origin header.
        if (!origin || origins.includes(origin) || localhostOrigin.test(origin)) {
          cb(null, true);
          return;
        }
        cb(null, false);
      },
      credentials: true,
      methods: ["GET", "HEAD", "PUT", "PATCH", "POST", "DELETE", "OPTIONS"],
      allowedHeaders: ["Authorization", "Content-Type", "Accept"],
    }),
  );
  app.use(requestLogger);
  app.use(express.json({ limit: "16mb" }));

  registerRoutes(app);

  app.use((_req: Request, res: Response) => {
    res.status(404).json({ error: "Not found", source: "relay" });
  });

  app.use(relayErrorHandler);

  return app;
}
